-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 03 2015 г., 19:34
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `grapheme`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(1, 2, 'dictionaries', 'view', 1),
(2, 2, 'dictionaries', 'create', 1),
(3, 2, 'dictionaries', 'edit', 1),
(4, 2, 'dictionaries', 'delete', 1),
(5, 2, 'dictionaries', 'dicval_view', 1),
(6, 2, 'dictionaries', 'dicval_create', 1),
(7, 2, 'dictionaries', 'dicval_edit', 1),
(8, 2, 'dictionaries', 'dicval_delete', 1),
(9, 2, 'dictionaries', 'dicval_restore', 1),
(10, 2, 'dictionaries', 'settings', 1),
(11, 2, 'dictionaries', 'dicval_entity_view', 1),
(12, 2, 'dictionaries', 'hidden', 1),
(13, 2, 'dictionaries', 'import', 1),
(14, 2, 'galleries', 'view', 1),
(15, 2, 'galleries', 'create', 1),
(16, 2, 'galleries', 'edit', 1),
(17, 2, 'galleries', 'delete', 1),
(18, 2, 'pages', 'view', 1),
(19, 2, 'pages', 'create', 1),
(20, 2, 'pages', 'edit', 1),
(21, 2, 'pages', 'delete', 1),
(22, 2, 'pages', 'advanced', 1),
(23, 2, 'pages', 'page_restore', 1),
(24, 2, 'seo', 'edit', 1),
(25, 2, 'system', 'system', 1),
(26, 2, 'system', 'modules', 1),
(27, 2, 'system', 'groups', 1),
(28, 2, 'system', 'users', 1),
(29, 2, 'system', 'locale_editor', 1),
(30, 2, 'system', 'tpl_editor', 1),
(31, 2, 'system', 'menu_editor', 1),
(32, 2, 'uploads', 'view', 1),
(33, 2, 'uploads', 'create', 1),
(34, 2, 'uploads', 'delete', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_attributes`
--

DROP TABLE IF EXISTS `catalog_attributes`;
CREATE TABLE IF NOT EXISTS `catalog_attributes` (
`id` int(10) unsigned NOT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributes_group_id` int(10) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `settings` text COLLATE utf8_unicode_ci,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_attributes_groups`
--

DROP TABLE IF EXISTS `catalog_attributes_groups`;
CREATE TABLE IF NOT EXISTS `catalog_attributes_groups` (
`id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_attributes_groups_meta`
--

DROP TABLE IF EXISTS `catalog_attributes_groups_meta`;
CREATE TABLE IF NOT EXISTS `catalog_attributes_groups_meta` (
`id` int(10) unsigned NOT NULL,
  `attributes_group_id` int(10) unsigned NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_attributes_meta`
--

DROP TABLE IF EXISTS `catalog_attributes_meta`;
CREATE TABLE IF NOT EXISTS `catalog_attributes_meta` (
`id` int(10) unsigned NOT NULL,
  `attribute_id` int(10) unsigned NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_attributes_values`
--

DROP TABLE IF EXISTS `catalog_attributes_values`;
CREATE TABLE IF NOT EXISTS `catalog_attributes_values` (
`id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `attribute_id` int(10) unsigned NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_categories`
--

DROP TABLE IF EXISTS `catalog_categories`;
CREATE TABLE IF NOT EXISTS `catalog_categories` (
`id` int(10) unsigned NOT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '1',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned NOT NULL DEFAULT '0',
  `settings` text COLLATE utf8_unicode_ci,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_categories_meta`
--

DROP TABLE IF EXISTS `catalog_categories_meta`;
CREATE TABLE IF NOT EXISTS `catalog_categories_meta` (
`id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders`
--

DROP TABLE IF EXISTS `catalog_orders`;
CREATE TABLE IF NOT EXISTS `catalog_orders` (
`id` int(10) unsigned NOT NULL,
  `status_id` smallint(5) unsigned DEFAULT '1',
  `total_sum` float(8,2) unsigned NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `client_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_info` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders_products`
--

DROP TABLE IF EXISTS `catalog_orders_products`;
CREATE TABLE IF NOT EXISTS `catalog_orders_products` (
`id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `price` float(8,2) unsigned NOT NULL,
  `product_cache` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders_products_attributes`
--

DROP TABLE IF EXISTS `catalog_orders_products_attributes`;
CREATE TABLE IF NOT EXISTS `catalog_orders_products_attributes` (
`id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `attribute_id` int(10) unsigned DEFAULT NULL,
  `attribute_cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders_statuses`
--

DROP TABLE IF EXISTS `catalog_orders_statuses`;
CREATE TABLE IF NOT EXISTS `catalog_orders_statuses` (
`id` int(10) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders_statuses_history`
--

DROP TABLE IF EXISTS `catalog_orders_statuses_history`;
CREATE TABLE IF NOT EXISTS `catalog_orders_statuses_history` (
`id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `changer_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `changer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_cache` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_orders_statuses_meta`
--

DROP TABLE IF EXISTS `catalog_orders_statuses_meta`;
CREATE TABLE IF NOT EXISTS `catalog_orders_statuses_meta` (
`id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_products`
--

DROP TABLE IF EXISTS `catalog_products`;
CREATE TABLE IF NOT EXISTS `catalog_products` (
`id` int(10) unsigned NOT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `article` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` int(10) unsigned NOT NULL,
  `image_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gallery_id` int(10) unsigned NOT NULL DEFAULT '0',
  `settings` text COLLATE utf8_unicode_ci,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_products_meta`
--

DROP TABLE IF EXISTS `catalog_products_meta`;
CREATE TABLE IF NOT EXISTS `catalog_products_meta` (
`id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_related_products`
--

DROP TABLE IF EXISTS `catalog_related_products`;
CREATE TABLE IF NOT EXISTS `catalog_related_products` (
  `product_id` int(10) unsigned NOT NULL,
  `related_product_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `settings`, `created_at`, `updated_at`) VALUES
(1, 'jobs', 'Работы', 1, 'fa-archive', 1, NULL, 'Название проекта', 0, 0, NULL, 0, 1, NULL, NULL, '2015-03-03 10:44:31', '2015-03-03 10:44:31'),
(2, 'capabilities', 'Возможности', 1, 'fa-flag', 1, NULL, 'Название (только для админ.панели)', 0, 0, NULL, 0, 1, NULL, NULL, '2015-03-03 11:43:27', '2015-03-03 11:46:14'),
(3, 'clients', 'Клиенты', 1, 'fa-gift ', 1, NULL, 'Название (только для админ.панели)', 0, 0, NULL, 0, 1, NULL, NULL, '2015-03-03 12:14:37', '2015-03-03 12:14:37'),
(4, 'partners', 'Партнеры', 1, 'fa-puzzle-piece ', 1, NULL, 'Название (только для админ.панели)', 0, 0, NULL, 0, 1, NULL, NULL, '2015-03-03 12:24:38', '2015-03-03 12:24:38');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=131 ;

--
-- Дамп данных таблицы `dictionary_fields_values`
--

INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(25, 9, 'ru', 'background', '10', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(26, 9, 'en', 'background', '11', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(27, 9, 'ru', 'slogan', 'Роскошь во всех измерениях', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(28, 9, 'en', 'slogan', 'Luxury in all dimensions', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(29, 9, 'ru', 'site_url', '#', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(30, 9, 'en', 'site_url', '#', '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(31, 10, 'ru', 'background', '12', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(32, 10, 'en', 'background', '13', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(33, 10, 'ru', 'slogan', 'Новый формат отдыха', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(34, 10, 'en', 'slogan', 'The new format of rest', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(35, 10, 'ru', 'site_url', '', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(36, 10, 'en', 'site_url', '#', '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(37, 11, 'ru', 'background', '14', '2015-03-03 11:08:35', '2015-03-03 11:08:35'),
(38, 11, 'en', 'background', '15', '2015-03-03 11:08:36', '2015-03-03 11:08:36'),
(39, 11, 'ru', 'slogan', 'Отдых в Адыгее', '2015-03-03 11:08:36', '2015-03-03 11:08:36'),
(40, 11, 'en', 'slogan', 'Rest in Adygea', '2015-03-03 11:08:36', '2015-03-03 11:08:36'),
(41, 11, 'ru', 'site_url', '#', '2015-03-03 11:08:36', '2015-03-03 11:08:36'),
(42, 11, 'en', 'site_url', '#', '2015-03-03 11:08:36', '2015-03-03 11:08:36'),
(43, 12, 'ru', 'background', '16', '2015-03-03 11:09:19', '2015-03-03 11:09:19'),
(44, 12, 'en', 'background', '17', '2015-03-03 11:09:20', '2015-03-03 11:09:20'),
(45, 12, 'ru', 'slogan', 'Создавать события — наша работа', '2015-03-03 11:09:20', '2015-03-03 11:09:20'),
(46, 12, 'en', 'slogan', 'Create events - our work', '2015-03-03 11:09:20', '2015-03-03 11:09:20'),
(47, 12, 'ru', 'site_url', '#', '2015-03-03 11:09:20', '2015-03-03 11:09:20'),
(48, 12, 'en', 'site_url', '#', '2015-03-03 11:09:20', '2015-03-03 11:09:20'),
(49, 13, 'ru', 'title', 'Веб-сайты', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(50, 13, 'en', 'title', 'Web-sites', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(51, 13, 'ru', 'background', '18', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(52, 13, 'en', 'background', '19', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(53, 14, 'ru', 'title', 'Мобильные приложения', '2015-03-03 11:50:47', '2015-03-03 11:50:47'),
(54, 14, 'en', 'title', 'Mobile Applications', '2015-03-03 11:50:48', '2015-03-03 11:50:48'),
(55, 14, 'ru', 'background', '20', '2015-03-03 11:50:48', '2015-03-03 11:50:48'),
(56, 14, 'en', 'background', '21', '2015-03-03 11:50:48', '2015-03-03 11:50:48'),
(57, 15, 'ru', 'title', 'SEO-оптимизация', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(58, 15, 'en', 'title', 'SEO-optimization', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(59, 15, 'ru', 'background', '23', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(60, 15, 'en', 'background', '22', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(61, 16, 'ru', 'title', 'SMM', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(62, 16, 'en', 'title', 'SMM', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(63, 16, 'ru', 'background', '25', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(64, 16, 'en', 'background', '24', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(65, 17, 'ru', 'title', 'UX-проектирование', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(66, 17, 'en', 'title', 'UX-design', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(67, 17, 'ru', 'background', '27', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(68, 17, 'en', 'background', '26', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(69, 18, 'ru', 'title', 'Поддержка и сопровождение', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(70, 18, 'en', 'title', 'Support and maintenance', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(71, 18, 'ru', 'background', '29', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(72, 18, 'en', 'background', '28', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(73, 19, 'ru', 'title', 'E-commerce', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(74, 19, 'en', 'title', 'E-commerce', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(75, 19, 'ru', 'background', '31', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(76, 19, 'en', 'background', '30', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(77, 20, 'ru', 'title', 'Email маркетинг', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(78, 20, 'en', 'title', 'Email Marketing', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(79, 20, 'ru', 'background', '33', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(80, 20, 'en', 'background', '32', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(81, 21, 'ru', 'title', 'Брендинг', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(82, 21, 'en', 'title', 'Branding', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(83, 21, 'ru', 'background', '35', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(84, 21, 'en', 'background', '34', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(85, 22, 'ru', 'title', 'Стратегия и креатив', '2015-03-03 12:06:16', '2015-03-03 12:06:16'),
(86, 22, 'en', 'title', 'Стратегия и креатив', '2015-03-03 12:06:16', '2015-03-03 12:06:16'),
(87, 22, 'ru', 'background', '36', '2015-03-03 12:06:16', '2015-03-03 12:06:16'),
(88, 22, 'en', 'background', '37', '2015-03-03 12:06:16', '2015-03-03 12:06:16'),
(89, 23, 'ru', 'title', 'Infinfiti', '2015-03-03 12:16:13', '2015-03-03 12:16:13'),
(90, 23, 'en', 'title', 'Infinfiti', '2015-03-03 12:16:13', '2015-03-03 12:16:13'),
(91, 23, 'ru', 'background', '39', '2015-03-03 12:16:13', '2015-03-03 12:16:13'),
(92, 23, 'en', 'background', '38', '2015-03-03 12:16:13', '2015-03-03 12:16:13'),
(93, 24, 'ru', 'title', 'Univeler', '2015-03-03 12:17:00', '2015-03-03 12:17:00'),
(94, 24, 'en', 'title', 'Univeler', '2015-03-03 12:17:00', '2015-03-03 12:17:00'),
(95, 24, 'ru', 'background', '41', '2015-03-03 12:17:00', '2015-03-03 12:17:00'),
(96, 24, 'en', 'background', '40', '2015-03-03 12:17:00', '2015-03-03 12:17:00'),
(97, 25, 'ru', 'title', 'Rutech Project', '2015-03-03 12:17:44', '2015-03-03 12:17:44'),
(98, 25, 'en', 'title', 'Rutech Project', '2015-03-03 12:17:44', '2015-03-03 12:17:44'),
(99, 25, 'ru', 'background', '43', '2015-03-03 12:17:44', '2015-03-03 12:17:44'),
(100, 25, 'en', 'background', '42', '2015-03-03 12:17:44', '2015-03-03 12:17:44'),
(101, 26, 'ru', 'title', 'UPC', '2015-03-03 12:18:39', '2015-03-03 12:18:39'),
(102, 26, 'en', 'title', 'UPC', '2015-03-03 12:18:39', '2015-03-03 12:18:39'),
(103, 26, 'ru', 'background', '45', '2015-03-03 12:18:39', '2015-03-03 12:18:39'),
(104, 26, 'en', 'background', '44', '2015-03-03 12:18:39', '2015-03-03 12:18:39'),
(105, 27, 'ru', 'title', 'Arredamenti', '2015-03-03 12:19:31', '2015-03-03 12:19:31'),
(106, 27, 'en', 'title', 'Arredamenti', '2015-03-03 12:19:31', '2015-03-03 12:19:31'),
(107, 27, 'ru', 'background', '46', '2015-03-03 12:19:31', '2015-03-03 12:19:31'),
(108, 27, 'en', 'background', '47', '2015-03-03 12:19:31', '2015-03-03 12:19:31'),
(109, 28, 'ru', 'title', 'Цимлянское', '2015-03-03 12:20:04', '2015-03-03 12:20:04'),
(110, 28, 'en', 'title', 'Цимлянское', '2015-03-03 12:20:04', '2015-03-03 12:20:04'),
(111, 28, 'ru', 'background', '49', '2015-03-03 12:20:04', '2015-03-03 12:20:04'),
(112, 28, 'en', 'background', '48', '2015-03-03 12:20:04', '2015-03-03 12:20:04'),
(113, 29, 'ru', 'title', 'Pichesky', '2015-03-03 12:25:30', '2015-03-03 12:25:30'),
(114, 29, 'en', 'title', 'Pichesky', '2015-03-03 12:25:30', '2015-03-03 12:25:30'),
(115, 29, 'ru', 'background', '51', '2015-03-03 12:25:30', '2015-03-03 12:25:30'),
(116, 29, 'en', 'background', '50', '2015-03-03 12:25:30', '2015-03-03 12:25:30'),
(117, 30, 'ru', 'title', 'Redkeds', '2015-03-03 12:26:07', '2015-03-03 12:26:07'),
(118, 30, 'en', 'title', 'Redkeds', '2015-03-03 12:26:07', '2015-03-03 12:26:07'),
(119, 30, 'ru', 'background', '56', '2015-03-03 12:26:07', '2015-03-03 12:29:37'),
(120, 30, 'en', 'background', '52', '2015-03-03 12:26:07', '2015-03-03 12:26:07'),
(121, 31, 'ru', 'title', 'Func.', '2015-03-03 12:26:46', '2015-03-03 12:26:46'),
(122, 31, 'en', 'title', 'Func.', '2015-03-03 12:26:46', '2015-03-03 12:26:46'),
(123, 31, 'ru', 'background', '55', '2015-03-03 12:26:46', '2015-03-03 12:26:46'),
(124, 31, 'en', 'background', '54', '2015-03-03 12:26:46', '2015-03-03 12:26:46'),
(125, 29, 'ru', 'site_url', '#', '2015-03-03 12:28:59', '2015-03-03 12:28:59'),
(126, 29, 'en', 'site_url', '#', '2015-03-03 12:28:59', '2015-03-03 12:30:07'),
(127, 30, 'ru', 'site_url', '#', '2015-03-03 12:29:37', '2015-03-03 12:29:37'),
(128, 30, 'en', 'site_url', '#', '2015-03-03 12:29:37', '2015-03-03 12:29:37'),
(129, 31, 'ru', 'site_url', '#', '2015-03-03 12:30:14', '2015-03-03 12:30:14'),
(130, 31, 'en', 'site_url', '#', '2015-03-03 12:30:14', '2015-03-03 12:30:14');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `dictionary_textfields_values`
--

INSERT INTO `dictionary_textfields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 13, 'ru', 'description', '<p>\r\n	Осуществляем разработку веб-сайтов, интерактивных платформ и интранет- систем.\r\n</p>', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(2, 13, 'en', 'description', '<p>\r\n	We provide website development, interactive platforms and intranet systems.\r\n</p>', '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(3, 14, 'ru', 'description', '<p>\r\n	Проектируем, разрабатываем и продвигаем мобильные приложения под платформыiOS и Android.\r\n</p>', '2015-03-03 11:50:48', '2015-03-03 11:50:48'),
(4, 14, 'en', 'description', '<p>\r\n	We design, develop and promote mobile applications under platformyiOS and Android.\r\n</p>', '2015-03-03 11:50:48', '2015-03-03 11:50:48'),
(5, 15, 'ru', 'description', '<p>\r\n	Помогаем оптимизировать работу сайта и увеличить трафик. Анализ,  оптимизация работы сайта, разработка стратегии SEO и поддержка на более  поздних этапах ее функционирования.\r\n</p>', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(6, 15, 'en', 'description', '<p>\r\n	Help optimize the performance of the site and increase your traffic. Analysis, optimization of the site, the development of SEO strategies and support in the later stages of its operation.\r\n</p>', '2015-03-03 11:51:44', '2015-03-03 11:51:44'),
(7, 16, 'ru', 'description', '<p>\r\n	Повышаем лояльность целевой аудитории в социальных медиа. Изучаем  позиционирование историю развития бренда и поддерживаем SMM-стратегию с  помощью широкого арсенала средств.\r\n</p>', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(8, 16, 'en', 'description', '<p>\r\n	Increases the loyalty of the target audience in social media. Study the history of the brand positioning and support SMM-strategy with a wide range of means.\r\n</p>', '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(9, 17, 'ru', 'description', '<p>\r\n	Разработка интерфейсов и оптимизация пользовательского взаимодействия с системой, оптимизация и структурирование компонентов.\r\n</p>', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(10, 17, 'en', 'description', '<p>\r\n	Interface development and optimization of user interaction with the system, optimization and structuring components.\r\n</p>', '2015-03-03 11:53:21', '2015-03-03 11:53:21'),
(11, 18, 'ru', 'description', '<p>\r\n	Оказываем комплексную поддержку сайтов и ecommercя систем. Техническая, контентная и аналитическая поддержка.\r\n</p>', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(12, 18, 'en', 'description', '<p>\r\n	We provide comprehensive support sites and ecommercya systems. Technical, content and analytical support.\r\n</p>', '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(13, 19, 'ru', 'description', '<p>\r\n	Оптимизируем и корректируем работу сайтов, направленных на онлайн продажу товаров и услуг.\r\n</p>', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(14, 19, 'en', 'description', '<p>\r\n	Optimize and adjust job sites aimed at the online sale of goods and services.\r\n</p>', '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(15, 20, 'ru', 'description', '<p>\r\n	Осуществляем продвижение бренда и его товаров посредством электронной почты на основе исследований ЦА.\r\n</p>', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(16, 20, 'en', 'description', '<p>\r\n	We provide brand promotion and its products via e-mail on the basis of studies in Central Asia.\r\n</p>', '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(17, 21, 'ru', 'description', '<p>\r\n	Создаем и продвигаем бренды в Интернете, разрабатывая нейминг, фирменный стиль и айдентику.\r\n</p>', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(18, 21, 'en', 'description', '', '2015-03-03 12:05:21', '2015-03-03 12:05:21'),
(19, 22, 'ru', 'description', '<p>\r\n	Изучаем медиа-пространство и планируем решение бизнес задач в Digital  среде. Разработка комплексной стратегии онлайн-присутствия.\r\n</p>', '2015-03-03 12:06:16', '2015-03-03 12:06:16'),
(20, 22, 'en', 'description', '<p>\r\n	Изучаем медиа-пространство и планируем решение бизнес задач в Digital  среде. Разработка комплексной стратегии онлайн-присутствия.\r\n</p>', '2015-03-03 12:06:16', '2015-03-03 12:06:16');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `lft`, `rgt`, `created_at`, `updated_at`) VALUES
(9, NULL, 1, NULL, 'INFINITI', NULL, 1, 2, '2015-03-03 11:07:16', '2015-03-03 11:07:16'),
(10, NULL, 1, NULL, 'St.Tropez', NULL, 3, 4, '2015-03-03 11:07:59', '2015-03-03 11:07:59'),
(11, NULL, 1, NULL, 'Даховская слобода', NULL, 5, 6, '2015-03-03 11:08:35', '2015-03-03 11:08:35'),
(12, NULL, 1, NULL, 'People-around.ru', NULL, 7, 8, '2015-03-03 11:09:19', '2015-03-03 11:09:19'),
(13, NULL, 2, NULL, 'Веб-сайты', NULL, 1, 2, '2015-03-03 11:49:44', '2015-03-03 11:49:44'),
(14, NULL, 2, NULL, 'Мобильные приложения', NULL, 3, 4, '2015-03-03 11:50:47', '2015-03-03 11:50:47'),
(15, NULL, 2, NULL, 'SEO-оптимизация', NULL, 5, 6, '2015-03-03 11:51:43', '2015-03-03 11:51:43'),
(16, NULL, 2, NULL, 'SMM', NULL, 7, 8, '2015-03-03 11:52:29', '2015-03-03 11:52:29'),
(17, NULL, 2, NULL, 'UX-проектирование', NULL, 9, 10, '2015-03-03 11:53:20', '2015-03-03 11:53:21'),
(18, NULL, 2, NULL, 'Поддержка и сопровождение', NULL, 11, 12, '2015-03-03 11:54:14', '2015-03-03 11:54:14'),
(19, NULL, 2, NULL, 'E-commerce', NULL, 13, 14, '2015-03-03 11:55:02', '2015-03-03 11:55:02'),
(20, NULL, 2, NULL, 'Email маркетинг', NULL, 15, 16, '2015-03-03 11:55:53', '2015-03-03 11:55:53'),
(21, NULL, 2, NULL, 'Брендинг', NULL, 17, 18, '2015-03-03 12:05:20', '2015-03-03 12:05:21'),
(22, NULL, 2, NULL, 'Стратегия и креатив', NULL, 19, 20, '2015-03-03 12:06:15', '2015-03-03 12:06:15'),
(23, NULL, 3, NULL, 'INFINITI', NULL, 1, 2, '2015-03-03 12:16:13', '2015-03-03 12:16:13'),
(24, NULL, 3, NULL, 'Univeler', NULL, 3, 4, '2015-03-03 12:17:00', '2015-03-03 12:17:00'),
(25, NULL, 3, NULL, 'Rutech Project', NULL, 5, 6, '2015-03-03 12:17:44', '2015-03-03 12:17:44'),
(26, NULL, 3, NULL, 'UPC', NULL, 7, 8, '2015-03-03 12:18:39', '2015-03-03 12:18:39'),
(27, NULL, 3, NULL, 'Arredamenti', NULL, 9, 10, '2015-03-03 12:19:31', '2015-03-03 12:19:31'),
(28, NULL, 3, NULL, 'Цимлянское', NULL, 11, 12, '2015-03-03 12:20:04', '2015-03-03 12:20:04'),
(29, NULL, 4, NULL, 'Pichesky', NULL, 1, 2, '2015-03-03 12:25:30', '2015-03-03 12:30:07'),
(30, NULL, 4, NULL, 'Redkeds', NULL, 3, 4, '2015-03-03 12:26:06', '2015-03-03 12:29:37'),
(31, NULL, 4, NULL, 'Func', NULL, 5, 6, '2015-03-03 12:26:46', '2015-03-03 12:30:14');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_parent_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_child_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_parent_field` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'developer', 'Разработчики', 'admin', '', '2015-03-02 10:21:48', '2015-03-02 10:21:48'),
(2, 'admin', 'Администраторы', 'admin', '', '2015-03-02 10:21:48', '2015-03-02 11:00:11'),
(3, 'moderator', 'Модераторы', 'admin', '', '2015-03-02 10:21:48', '2015-03-02 10:21:48');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2014_11_18_161140_create_catalog_tables', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'dictionaries', 1, 0, '2015-03-02 10:21:49', '2015-03-02 10:21:49'),
(2, 'pages', 1, 1, '2015-03-02 10:21:49', '2015-03-02 10:21:49'),
(3, 'galleries', 1, 2, '2015-03-02 10:21:49', '2015-03-02 10:21:49'),
(4, 'seo', 1, 3, '2015-03-02 10:21:49', '2015-03-02 10:21:49'),
(5, 'catalog', 0, 4, '2015-03-02 10:21:49', '2015-03-02 10:59:55'),
(6, 'system', 1, 5, '2015-03-02 10:21:49', '2015-03-02 10:59:54'),
(7, 'uploads', 1, 0, '2015-03-02 10:59:52', '2015-03-02 10:59:52');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=65 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `template`, `type_id`, `publication`, `start_page`, `in_menu`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Grapheme', 'index', 'index', NULL, 1, 1, NULL, NULL, '2015-03-02 11:39:38', '2015-03-02 11:52:55'),
(9, 1, 'Grapheme', 'grapheme', 'index', NULL, 1, NULL, NULL, NULL, '2015-03-02 11:52:54', '2015-03-02 11:52:55'),
(10, NULL, 'Портфолио', 'portfolio', 'portfolio', NULL, 1, NULL, NULL, NULL, '2015-03-02 12:21:02', '2015-03-02 12:21:26'),
(11, 10, 'Портфолио', 'portfolio-link', 'index', NULL, 1, NULL, NULL, NULL, '2015-03-02 12:21:26', '2015-03-02 12:21:26'),
(12, NULL, 'Агенство', 'about', 'about', NULL, 1, NULL, NULL, NULL, '2015-03-02 12:55:58', '2015-03-02 12:55:58'),
(22, NULL, 'Поддежка', 'support', 'support', NULL, 1, NULL, NULL, NULL, '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(36, 22, 'Поддежка', 'support', 'support', NULL, 1, NULL, NULL, NULL, '2015-03-03 06:47:07', '2015-03-03 06:47:07'),
(37, 12, 'Агенство', 'about', 'about', NULL, 1, NULL, NULL, NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(38, NULL, 'SEO', 'seo', 'seo', NULL, 1, NULL, NULL, NULL, '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(50, 38, 'SEO', 'seo', 'seo', NULL, 1, NULL, NULL, NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(51, NULL, 'SMM', 'smm', 'smm', NULL, 1, NULL, NULL, NULL, '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(64, 51, 'SMM', 'smm', 'smm', NULL, 1, NULL, NULL, NULL, '2015-03-03 09:52:34', '2015-03-03 09:52:34');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=470 ;

--
-- Дамп данных таблицы `pages_blocks`
--

INSERT INTO `pages_blocks` (`id`, `page_id`, `name`, `slug`, `desc`, `template`, `order`, `created_at`, `updated_at`) VALUES
(1, 1, 'Название страницы', 'div_title', NULL, NULL, 0, '2015-03-02 11:39:39', '2015-03-02 11:39:39'),
(3, 1, 'Описание страницы', 'div_desc', NULL, NULL, 1, '2015-03-02 11:42:25', '2015-03-02 11:42:25'),
(8, 1, 'Ссылка на портфолио', 'portfolio_link', NULL, NULL, 2, '2015-03-02 11:43:30', '2015-03-02 11:43:30'),
(21, 9, 'Название страницы', 'div_title', NULL, NULL, 0, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(22, 9, 'Описание страницы', 'div_desc', NULL, NULL, 1, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(23, 9, 'Ссылка на портфолио', 'portfolio_link', NULL, NULL, 2, '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(24, 12, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-02 13:13:15', '2015-03-02 13:13:15'),
(26, 12, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-02 13:20:24', '2015-03-02 13:20:24'),
(27, 12, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-02 13:20:24', '2015-03-02 13:20:24'),
(31, 12, 'Средний центральный блок', 'medium_title_block', NULL, NULL, 3, '2015-03-03 05:49:58', '2015-03-03 05:49:58'),
(36, 12, 'Средний первый блок', 'medium_first_block', NULL, NULL, 4, '2015-03-03 05:51:33', '2015-03-03 05:51:33'),
(42, 12, 'Средний второй блок', 'medium_second_block', NULL, NULL, 5, '2015-03-03 05:53:03', '2015-03-03 05:53:03'),
(49, 12, 'Средний третий блок', 'medium_third_block', NULL, NULL, 6, '2015-03-03 05:55:05', '2015-03-03 05:55:27'),
(64, 12, 'Партнеры', 'partners_title_block', NULL, NULL, 7, '2015-03-03 06:01:34', '2015-03-03 06:01:34'),
(65, 12, 'Партнеры описание', 'partners_description_block', NULL, NULL, 8, '2015-03-03 06:01:34', '2015-03-03 06:01:34'),
(75, 12, 'Клиенты', 'clients_title_block', NULL, NULL, 9, '2015-03-03 06:05:34', '2015-03-03 06:05:34'),
(76, 22, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(78, 22, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-03 06:16:20', '2015-03-03 06:16:20'),
(81, 22, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-03 06:16:35', '2015-03-03 06:16:35'),
(85, 22, 'Поддержка и сопровождение', 'medium_title_block', NULL, NULL, 3, '2015-03-03 06:21:21', '2015-03-03 06:38:07'),
(90, 22, 'Базовая техническая поддержка', 'medium_first_block', NULL, NULL, 4, '2015-03-03 06:22:50', '2015-03-03 06:38:07'),
(91, 22, 'Стратегическое развитие', 'medium_third_block', NULL, NULL, 6, '2015-03-03 06:22:51', '2015-03-03 06:38:07'),
(92, 22, 'Аналитическая поддержка', 'medium_four_block', NULL, NULL, 7, '2015-03-03 06:22:51', '2015-03-03 06:38:07'),
(109, 22, 'Контентная поддержка', 'medium_second_block', NULL, NULL, 5, '2015-03-03 06:33:27', '2015-03-03 06:38:07'),
(126, 22, 'Уверенность в собственных силах', 'self-confidence', NULL, NULL, 8, '2015-03-03 06:38:07', '2015-03-03 06:38:07'),
(136, 22, 'Поддержка и развитие', 'bottom_title_block', NULL, NULL, 9, '2015-03-03 06:42:18', '2015-03-03 06:42:18'),
(157, 22, 'Поддержка и развитие первый блок', 'bottom_first_block', NULL, NULL, 10, '2015-03-03 06:43:38', '2015-03-03 06:43:57'),
(180, 22, 'Поддержка и развитие второй блок', 'bottom_second_block', NULL, NULL, 11, '2015-03-03 06:45:27', '2015-03-03 06:45:27'),
(181, 36, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 06:47:07', '2015-03-03 06:47:07'),
(182, 36, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(183, 36, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(184, 36, 'Поддержка и сопровождение', 'medium_title_block', NULL, NULL, 3, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(185, 36, 'Базовая техническая поддержка', 'medium_first_block', NULL, NULL, 4, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(186, 36, 'Контентная поддержка', 'medium_second_block', NULL, NULL, 5, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(187, 36, 'Стратегическое развитие', 'medium_third_block', NULL, NULL, 6, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(188, 36, 'Аналитическая поддержка', 'medium_four_block', NULL, NULL, 7, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(189, 36, 'Уверенность в собственных силах', 'self-confidence', NULL, NULL, 8, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(190, 36, 'Поддержка и развитие', 'bottom_title_block', NULL, NULL, 9, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(191, 36, 'Поддержка и развитие первый блок', 'bottom_first_block', NULL, NULL, 10, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(192, 36, 'Поддержка и развитие второй блок', 'bottom_second_block', NULL, NULL, 11, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(193, 22, 'Поддержка и развитие третий блок', 'bottom_third_block', NULL, NULL, 12, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(194, 37, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(195, 37, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(196, 37, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(197, 37, 'Средний центральный блок', 'medium_title_block', NULL, NULL, 3, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(198, 37, 'Средний первый блок', 'medium_first_block', NULL, NULL, 4, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(199, 37, 'Средний второй блок', 'medium_second_block', NULL, NULL, 5, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(200, 37, 'Средний третий блок', 'medium_third_block', NULL, NULL, 6, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(201, 37, 'Партнеры', 'partners_title_block', NULL, NULL, 7, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(202, 37, 'Партнеры описание', 'partners_description_block', NULL, NULL, 8, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(203, 37, 'Клиенты', 'clients_title_block', NULL, NULL, 9, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(204, 38, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(206, 38, 'Результаты SEO', 'result-seo_title', NULL, NULL, 1, '2015-03-03 07:35:43', '2015-03-03 07:35:59'),
(211, 38, 'Повышение конверсии', 'povyshenie-konversii', NULL, NULL, 2, '2015-03-03 07:38:45', '2015-03-03 07:38:45'),
(212, 38, 'Привлечение посетителей', 'privlechenie-posetiteley', NULL, NULL, 3, '2015-03-03 07:38:45', '2015-03-03 07:38:45'),
(213, 38, 'Улучшение работы сайта и отдела продаж', 'uluchshenie-raboty-sayta-i-otdela-prodaj', NULL, NULL, 4, '2015-03-03 07:38:45', '2015-03-03 07:38:45'),
(219, 38, 'Заказ SEO у нас', 'zakaz-seo-u-nas', NULL, NULL, 5, '2015-03-03 07:45:13', '2015-03-03 07:45:13'),
(220, 38, 'Думаем', 'dumaem', NULL, NULL, 6, '2015-03-03 07:45:13', '2015-03-03 07:45:13'),
(221, 38, 'Точно знаем, что необходимо', 'tochno-znaem-chto-neobhodimo', NULL, NULL, 7, '2015-03-03 07:45:13', '2015-03-03 07:45:13'),
(230, 38, 'Ценим время', 'cenim-vremya', NULL, NULL, 8, '2015-03-03 07:52:51', '2015-03-03 07:52:51'),
(231, 38, 'Поддерживаем', 'podderjivaem', NULL, NULL, 9, '2015-03-03 07:52:51', '2015-03-03 07:52:51'),
(242, 38, 'Продвижение уже сегодня', 'prodvijenie-uje-segodnya', NULL, NULL, 10, '2015-03-03 07:56:39', '2015-03-03 07:56:39'),
(254, 38, 'Стоит оптимизация', 'stoit-optimizaciya', NULL, NULL, 11, '2015-03-03 07:57:41', '2015-03-03 07:57:41'),
(267, 38, 'Стоимость типового проекта', 'stoit-optimizaciya-desc', NULL, NULL, 12, '2015-03-03 08:01:45', '2015-03-03 08:01:45'),
(281, 38, 'Продвижение сферы бизнеса', 'prodvijenie-sfery-biznesa', NULL, NULL, 13, '2015-03-03 08:05:24', '2015-03-03 08:05:24'),
(296, 38, 'Конкретный результ', 'konkretnyy-rezult', NULL, NULL, 14, '2015-03-03 08:22:47', '2015-03-03 08:22:47'),
(312, 38, 'Гарантия ГРАФЕМА', 'garantiya-grafema', NULL, NULL, 15, '2015-03-03 08:24:33', '2015-03-03 08:24:33'),
(313, 50, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(314, 50, 'Результаты SEO', 'result-seo_title', NULL, NULL, 1, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(315, 50, 'Повышение конверсии', 'povyshenie-konversii', NULL, NULL, 2, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(316, 50, 'Привлечение посетителей', 'privlechenie-posetiteley', NULL, NULL, 3, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(317, 50, 'Улучшение работы сайта и отдела продаж', 'uluchshenie-raboty-sayta-i-otdela-prodaj', NULL, NULL, 4, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(318, 50, 'Заказ SEO у нас', 'zakaz-seo-u-nas', NULL, NULL, 5, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(319, 50, 'Думаем', 'dumaem', NULL, NULL, 6, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(320, 50, 'Точно знаем, что необходимо', 'tochno-znaem-chto-neobhodimo', NULL, NULL, 7, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(321, 50, 'Ценим время', 'cenim-vremya', NULL, NULL, 8, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(322, 50, 'Поддерживаем', 'podderjivaem', NULL, NULL, 9, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(323, 50, 'Продвижение уже сегодня', 'prodvijenie-uje-segodnya', NULL, NULL, 10, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(324, 50, 'Стоит оптимизация', 'stoit-optimizaciya', NULL, NULL, 11, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(325, 50, 'Стоимость типового проекта', 'stoit-optimizaciya-desc', NULL, NULL, 12, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(326, 50, 'Продвижение сферы бизнеса', 'prodvijenie-sfery-biznesa', NULL, NULL, 13, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(327, 50, 'Конкретный результ', 'konkretnyy-rezult', NULL, NULL, 14, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(328, 50, 'Гарантия ГРАФЕМА', 'garantiya-grafema', NULL, NULL, 15, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(329, 38, 'Конкретный результ описание', 'konkretnyy-rezult-desc', NULL, NULL, 16, '2015-03-03 08:26:02', '2015-03-03 08:26:02'),
(330, 51, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(332, 51, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-03 08:32:48', '2015-03-03 08:32:48'),
(333, 51, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-03 08:32:48', '2015-03-03 08:32:48'),
(337, 51, 'Результаты SMM', 'rezultaty-smm', NULL, NULL, 3, '2015-03-03 08:48:19', '2015-03-03 08:48:19'),
(342, 51, 'Результаты SMM описание', 'rezultaty-smm-desc-left', NULL, NULL, 4, '2015-03-03 08:49:51', '2015-03-03 08:54:35'),
(353, 51, 'Результаты SMM описание', 'rezultaty-smm-desc-right', NULL, NULL, 5, '2015-03-03 08:55:03', '2015-03-03 08:55:03'),
(360, 51, 'Средний центральный блок', 'medium_title_block', NULL, NULL, 6, '2015-03-03 08:56:51', '2015-03-03 08:56:51'),
(368, 51, 'Этапы работы', 'etapy-raboty', NULL, NULL, 7, '2015-03-03 08:58:19', '2015-03-03 08:58:19'),
(377, 51, 'Аналитика', 'analitika', NULL, NULL, 8, '2015-03-03 08:59:43', '2015-03-03 08:59:43'),
(378, 51, 'Планирование', 'planirovanie', NULL, NULL, 9, '2015-03-03 08:59:43', '2015-03-03 08:59:43'),
(379, 51, 'Производство', 'proizvodstvo', NULL, NULL, 10, '2015-03-03 08:59:43', '2015-03-03 08:59:43'),
(380, 51, 'Публикация', 'publikaciya', NULL, NULL, 11, '2015-03-03 08:59:43', '2015-03-03 08:59:43'),
(381, 51, 'Поддержка бренда в соцсетях', 'podderjka-brenda-v-socsetyah', NULL, NULL, 12, '2015-03-03 08:59:43', '2015-03-03 08:59:43'),
(395, 51, 'Доверить SMM нам', 'doverit-smm-nam', NULL, NULL, 13, '2015-03-03 09:34:44', '2015-03-03 09:34:44'),
(410, 51, 'Стратегия', 'strategiya', NULL, NULL, 14, '2015-03-03 09:36:57', '2015-03-03 09:36:57'),
(411, 51, 'Опыт', 'opyt', NULL, NULL, 15, '2015-03-03 09:36:57', '2015-03-03 09:36:57'),
(412, 51, 'Внимание', 'vnimanie', NULL, NULL, 16, '2015-03-03 09:36:57', '2015-03-03 09:36:57'),
(430, 51, 'Работа в соцсетях', 'rabota-v-socsetyah', NULL, NULL, 17, '2015-03-03 09:48:26', '2015-03-03 09:48:26'),
(449, 51, 'Типичный проект по SMM', 'tipichnyy-proekt-po-smm', NULL, NULL, 18, '2015-03-03 09:50:33', '2015-03-03 09:50:33'),
(450, 64, 'Основное описание', 'main_title', NULL, NULL, 0, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(451, 64, 'Верхний левый блок', 'top_left_block', NULL, NULL, 1, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(452, 64, 'Верхний правый блок', 'top_right_block', NULL, NULL, 2, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(453, 64, 'Результаты SMM', 'rezultaty-smm', NULL, NULL, 3, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(454, 64, 'Результаты SMM описание', 'rezultaty-smm-desc-left', NULL, NULL, 4, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(455, 64, 'Результаты SMM описание', 'rezultaty-smm-desc-right', NULL, NULL, 5, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(456, 64, 'Средний центральный блок', 'medium_title_block', NULL, NULL, 6, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(457, 64, 'Этапы работы', 'etapy-raboty', NULL, NULL, 7, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(458, 64, 'Аналитика', 'analitika', NULL, NULL, 8, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(459, 64, 'Планирование', 'planirovanie', NULL, NULL, 9, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(460, 64, 'Производство', 'proizvodstvo', NULL, NULL, 10, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(461, 64, 'Публикация', 'publikaciya', NULL, NULL, 11, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(462, 64, 'Поддержка бренда в соцсетях', 'podderjka-brenda-v-socsetyah', NULL, NULL, 12, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(463, 64, 'Доверить SMM нам', 'doverit-smm-nam', NULL, NULL, 13, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(464, 64, 'Стратегия', 'strategiya', NULL, NULL, 14, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(465, 64, 'Опыт', 'opyt', NULL, NULL, 15, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(466, 64, 'Внимание', 'vnimanie', NULL, NULL, 16, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(467, 64, 'Работа в соцсетях', 'rabota-v-socsetyah', NULL, NULL, 17, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(468, 64, 'Типичный проект по SMM', 'tipichnyy-proekt-po-smm', NULL, NULL, 18, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(469, 51, 'Работа в соцсетях (доп.)', 'rabota-v-socsetyah-ext', NULL, NULL, 19, '2015-03-03 09:52:37', '2015-03-03 09:52:37');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
`id` int(10) unsigned NOT NULL,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=927 ;

--
-- Дамп данных таблицы `pages_blocks_meta`
--

INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '<p>\r\n	АНАЛИТИКА. ДИЗАЙН. ТЕХНОЛОГИИ.\r\n</p>', 'ru', NULL, '2015-03-02 11:40:43', '2015-03-02 11:40:43'),
(2, 1, NULL, 'ANALYST. DESIGN. TECHNOLOGY.', 'en', NULL, '2015-03-02 11:40:43', '2015-03-02 11:40:43'),
(5, 3, NULL, 'Мы занимаемся разработкой сайтов и мобильных приложений, продвижением в социальных медиа, поддержкой и сопровождением бизнеса онлайн.', 'ru', NULL, '2015-03-02 11:42:49', '2015-03-02 11:42:49'),
(6, 3, NULL, 'We have been developing websites and mobile applications, social media promotion, support and maintenance of online business.', 'en', NULL, '2015-03-02 11:42:49', '2015-03-02 11:42:49'),
(15, 8, NULL, 'Наши работы', 'ru', NULL, '2015-03-02 11:43:49', '2015-03-02 11:43:49'),
(16, 8, NULL, 'Our works', 'en', NULL, '2015-03-02 11:43:49', '2015-03-02 11:43:49'),
(41, 21, NULL, '<p>\r\n	АНАЛИТИКА. ДИЗАЙН. ТЕХНОЛОГИИ.\r\n</p>', 'ru', NULL, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(42, 21, NULL, 'ANALYST. DESIGN. TECHNOLOGY.', 'en', NULL, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(43, 22, NULL, 'Мы занимаемся разработкой сайтов и мобильных приложений, продвижением в социальных медиа, поддержкой и сопровождением бизнеса онлайн.', 'ru', NULL, '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(44, 22, NULL, 'We have been developing websites and mobile applications, social media promotion, support and maintenance of online business.', 'en', NULL, '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(45, 23, NULL, 'Наши работы', 'ru', NULL, '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(46, 23, NULL, 'Our works', 'en', NULL, '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(47, 24, NULL, 'Digital-продакшн агентство, Ростов-на-Дону.<br>\r\n Используя аналитический подход<br>\r\n и нестандартные решения, мы эффективно решаем<br>\r\n задачи наших клиентов.', 'ru', NULL, '2015-03-02 13:15:00', '2015-03-02 13:15:00'),
(48, 24, NULL, 'Digital-production agency, Rostov-on-Don. <br>\r\n Using an analytical approach <br>\r\n and innovative solutions, we effectively solve <br>\r\n problems of our clients.', 'en', NULL, '2015-03-02 13:15:01', '2015-03-02 13:15:01'),
(51, 26, NULL, 'Эффективный рабочий процесс предполагает полное взаимопонимание.                             Мы стремимся собирать вокруг себя людей, которые вдохновляют друг друга каждый день.                             Каждый из нас готов учить других и учиться сам, давать честную оценку своей деятельности                             и брать на себя личную ответственность. Мы убеждены, что такой подход — залог качественной работы.', 'ru', NULL, '2015-03-02 13:21:38', '2015-03-02 13:21:38'),
(52, 26, NULL, '<p>\r\n	 Efficient workflow assumes full understanding.<br>\r\n	 We aim to gather around him people who inspire each other every day.<br>\r\n	 Each of us is willing to teach others and learn myself, to give an honest assessment of their activities<br>\r\n	 and to take personal responsibility. We are convinced that this approach - the key to quality work.\r\n</p>', 'en', NULL, '2015-03-02 13:21:38', '2015-03-02 13:21:38'),
(53, 27, NULL, '<p>\r\n	 Сотрудники нашего агентства стремятся понять желания каждого клиента и воплотить их максимально эффективно. Проблемы клиента мы воспринимаем, как свои собственные, и предлагаем наиболее оптимальное решение. Мы всегда стремимся сделать больше, чем требуется, и открыто говорим о своих сомнениях, чтобы уверенно двигаться вперед.\r\n</p>', 'ru', NULL, '2015-03-02 13:23:25', '2015-03-02 13:23:25'),
(54, 27, NULL, '<p>\r\n	The staff of our agency seeking to understand each client''s desires and translate them effectively. Customer problems we perceive as their own, and offer the best solution. We always strive to do more than is required, and speak openly about their doubts to confidently move forward.\r\n</p>', 'en', NULL, '2015-03-02 13:23:25', '2015-03-02 13:23:25'),
(61, 31, NULL, '<p>\r\n	 Как мы обеспечиваем поддержку и развитие\r\n</p>', 'ru', NULL, '2015-03-03 05:50:43', '2015-03-03 05:50:43'),
(62, 31, NULL, '<p>\r\n	How do we provide support and development\r\n</p>', 'en', NULL, '2015-03-03 05:50:43', '2015-03-03 06:51:04'),
(71, 36, NULL, '<h3>Веб-сайты и мобильные приложения</h3>\r\n<p>\r\n	Наша цель - внедрение наиболее оптимальных решений для дизайна, интерфейса и юхабилити сайтов, порталов и мобильных приложений.\r\n</p>', 'ru', NULL, '2015-03-03 05:52:28', '2015-03-03 05:52:28'),
(72, 36, NULL, '<h3> Web sites and mobile applications \r\n</h3>\r\n<p>\r\n	 Our goal - the introduction of optimal solutions for design, interface and yuhabiliti sites, portals and mobile applications. \r\n</p>', 'en', NULL, '2015-03-03 05:52:28', '2015-03-03 06:51:27'),
(83, 42, NULL, '<h3>Развитие бизнеса в социальных медиа</h3>\r\n<p>\r\n	Работа с социальными медиа – ключевая часть любой рекламной кампании.bМы помогаем повысить лояльность к бренду, эффективно проинформировать ЦА и расширить присутствие бренда в сетию.\r\n</p>', 'ru', NULL, '2015-03-03 05:53:58', '2015-03-03 05:53:58'),
(84, 42, NULL, '<h3> Business Development in Social Media </h3>\r\n<p>\r\n	 Working with social media - a key part of any advertising kampanii.bMy help increase brand loyalty, effectively inform the CA and extend brand presence in setiyu.\r\n</p>', 'en', NULL, '2015-03-03 05:53:58', '2015-03-03 06:51:56'),
(109, 49, NULL, '<h3>SEO-оптимизация и Интернет-маркетинг</h3>\r\n<p>\r\n	Решаем комплексные задачи, помогающие продвижению бизнеса в онлайн-среде. Проводим анализ ситуации, разрабатываем стратегию продвижением и обеспечиваем поддержку сайтов.\r\n</p>', 'ru', NULL, '2015-03-03 05:56:00', '2015-03-03 05:56:00'),
(110, 49, NULL, '<h3> SEO-optimization and Internet Marketing</h3>\r\n<p>\r\n	 to solve complex problems, help promote business in the online environment. Analyze the situation, develop a strategy to promote and provide support sites. \r\n</p>', 'en', NULL, '2015-03-03 05:56:00', '2015-03-03 06:52:22'),
(125, 64, NULL, 'Наши партнеры', 'ru', NULL, '2015-03-03 06:02:10', '2015-03-03 06:02:10'),
(126, 64, NULL, 'Our partners', 'en', NULL, '2015-03-03 06:02:10', '2015-03-03 06:02:10'),
(127, 65, NULL, '<p>\r\n	Мы гордимся нашими партнерами и проектами, которые удалось реализовать вместе.\r\n</p>\r\n<p>\r\n	Мы всегда открыты к сотрудничеству с другими агентствами и охотно выслушаем все предложения по совместным проектам.\r\n</p>', 'ru', NULL, '2015-03-03 06:04:18', '2015-03-03 06:04:18'),
(128, 65, NULL, '<p>\r\n	 We are proud of our partners and projects that are able to realize together. \r\n</p>\r\n<p>\r\n	 We are always open to cooperation with other agencies and are willing to listen to all proposals for joint projects. \r\n</p>', 'en', NULL, '2015-03-03 06:04:18', '2015-03-03 06:52:53'),
(147, 75, NULL, 'Наши клиенты', 'ru', NULL, '2015-03-03 06:05:57', '2015-03-03 06:05:57'),
(148, 75, NULL, 'Our clients', 'en', NULL, '2015-03-03 06:05:57', '2015-03-03 06:05:57'),
(149, 76, NULL, '<p>\r\n	Сайты тоже нуждаются в постоянных изменениях, развитии и уходе. С нами ваши сайты будут чувствовать себя в полной безопасности.\r\n</p>', 'ru', NULL, '2015-03-03 06:15:40', '2015-03-03 06:15:40'),
(150, 76, NULL, '<p>\r\n	Sites also need to constant change, development and maintenance. With us, your sites will feel completely safe.\r\n</p>', 'en', NULL, '2015-03-03 06:15:40', '2015-03-03 06:15:40'),
(155, 78, NULL, '<p>\r\n	Рано или поздно любой, даже самый продуманный, сайт необходимо обновлять и развивать. Пока вы наслаждаетесь его безупречным внешним видом, содержание сайта и его техническая платформа устаревают.\r\n</p>', 'ru', NULL, '2015-03-03 06:17:54', '2015-03-03 06:17:54'),
(156, 78, NULL, '<p>\r\n	Sooner or later even the most thoughtful, the site must be updated and developed. While you enjoy its perfect appearance, content of the site and its technical platform becomes obsolete.\r\n</p>', 'en', NULL, '2015-03-03 06:17:55', '2015-03-03 06:17:55'),
(157, 81, NULL, '<p>\r\n	 Поддержка и сопровождение сайта призваны обеспечить его стабильную работу за счет своевременной диагностики и внесения изменений.\r\n</p>', 'ru', NULL, '2015-03-03 06:19:35', '2015-03-03 06:19:35'),
(158, 81, NULL, '<p>\r\n	Support and maintenance of the site are designed to provide its stable operation due to timely diagnosis and make changes.\r\n</p>', 'en', NULL, '2015-03-03 06:19:35', '2015-03-03 06:19:35'),
(165, 85, NULL, '<h2>Поддержка и сопровождение</h2>\r\n<p class="sub-header">\r\n	Существуют различные типы поддержки, которые мы готовы вам предложить.\r\n</p>', 'ru', NULL, '2015-03-03 06:22:01', '2015-03-03 06:22:01'),
(166, 85, NULL, '<h2> Support and maintenance </h2>\r\n<p class="sub-header">\r\n	 There are different types of support that we are ready to offer you. \r\n</p>', 'en', NULL, '2015-03-03 06:22:01', '2015-03-03 06:50:26'),
(175, 90, NULL, '<h3>Базовая техническая поддержка</h3>\r\n<p>\r\n	Обеспечивает работу и безопасность сайта 24 часа в сутки. Работа включает в себя аренду хостинг-площадки, резервное копирование баз данных и файлов проекта, мониторинг доступности и работоспособности сайта из дата-центров в России, Европе и США в зависимости от выбора аказчика. Мы проследим, чтобы ваш сайт всегда был доступен, а информация — неприкосновенна.\r\n</p>', 'ru', NULL, '2015-03-03 06:24:55', '2015-03-03 06:24:55'),
(176, 90, NULL, '<h3> Basic technical support \r\n</h3>\r\n<p>\r\n	 Provides work and security of the site 24 hours a day. The work includes rent hosting platform, database backup and project files, monitoring the availability and performance of the site data centers in Russia, Europe and the United States, depending on the choice of akazchika. We will make sure that your site has always been available, and information & mdash; inviolable. \r\n</p>', 'en', NULL, '2015-03-03 06:24:55', '2015-03-03 06:53:55'),
(177, 91, NULL, '<h3>Стратегическое развитие</h3>\r\n<p>\r\n	Комплексное сопровождение, создание стратегии онлайн-присутствия — наша любимая часть работы. Данный тип поддержки предполагает «взгляд со стороны» — оценку контента и анализ реакции пользователей на него, измерение эффективности и меры по оптимизации проектов. Мы работаем с любыми форматами, тематиками и инструментами и предлагаем собственные идеи по улучшению ваших проектов.\r\n</p>', 'ru', NULL, '2015-03-03 06:27:09', '2015-03-03 06:27:09'),
(178, 91, NULL, '<h3> Strategic Development </h3>\r\n<p>\r\n	 Comprehensive support, creating strategies online presence & mdash; Our favorite part of the job. This type of support is & laquo; view from & raquo; & mdash; evaluation of the content and analysis of user feedback on it, and measuring the effectiveness of measures to optimize projects. We work with any format, topics and tools and offer their own ideas for improving your projects.\r\n</p>', 'en', NULL, '2015-03-03 06:27:09', '2015-03-03 06:55:14'),
(179, 92, NULL, '<h3>Аналитическая поддержка</h3>\r\n<p>\r\n	Сбор и анализ статистической информации помогает понять, насколько эффективно работает сайт. Игнорировать эти показатели нельзя, как нельзя игнорировать пожелания и реакции своей целевой аудитории. Мы ежемесячно предоставляем вам отчеты о состоянии сайта и рекомендации, которые помогут в дальнейшей работе.\r\n</p>', 'ru', NULL, '2015-03-03 06:28:52', '2015-03-03 06:28:52'),
(180, 92, NULL, '<h3> Analytical Support</h3>\r\n<p>\r\n	 The collection and analysis of statistical information helps us to understand how effective the site. Ignore these indicators can not, as it is impossible to ignore the wishes and reactions of their target audience. We provide you with monthly reports on the status of the site and recommendations that will help in further work.\r\n</p>', 'en', NULL, '2015-03-03 06:28:52', '2015-03-03 06:55:48'),
(209, 109, NULL, '<h3>Контентная поддержка</h3>\r\n<p>\r\n	В работе с сайтами нельзя забывать об информационной динамике, которая требует своевременного обновления информации на сайте. Мы отслеживаем тренды и поведение конкурентов и задействуем инструменты по работе с контентом любого формата: тексты, инфографику, изображения и видео.\r\n</p>', 'ru', NULL, '2015-03-03 06:34:46', '2015-03-03 06:34:46'),
(210, 109, NULL, '<h3> Content Support</h3>\r\n<p>\r\n	 When working with sites should not forget about the dynamics of information, which requires the timely updating of information on this site. We monitor trends and competitor behavior and deploy the tools for working with content in any format: text, infographics, images and video. \r\n</p>', 'en', NULL, '2015-03-03 06:34:46', '2015-03-03 06:54:34'),
(243, 126, NULL, '<p>\r\n	Уверенность в собственных силах — это всегда большой плюс, но некоторые вещи лучше доверить специалистам.\r\n</p>', 'ru', NULL, '2015-03-03 06:40:31', '2015-03-03 06:40:31'),
(244, 126, NULL, '<p>\r\n	 Self-confidence — it is always a big plus, but some things are best left to professionals. \r\n	<!-- p-->\r\n</p>', 'en', NULL, '2015-03-03 06:40:31', '2015-03-03 06:40:31'),
(263, 136, NULL, '<p>\r\n	Как мы обеспечиваем поддержку и развитие\r\n</p>', 'ru', NULL, '2015-03-03 06:42:49', '2015-03-03 06:42:49'),
(264, 136, NULL, '<p>\r\n	How do we provide support and development\r\n</p>', 'en', NULL, '2015-03-03 06:42:49', '2015-03-03 06:42:49'),
(325, 157, NULL, '<h3>Неутомимость</h3>\r\n<p>\r\n	Мы реагируем на проблему в течение 15 минут и готовы консультировать по работе сайта и решению проблем 24 часа в сутки.\r\n</p>', 'ru', NULL, '2015-03-03 06:44:57', '2015-03-03 06:44:57'),
(326, 157, NULL, '<h3> Juggernaut </h3>\r\n<p>\r\n	 We will respond to the problem within 15 minutes and are ready to advise on the work site and solving problems 24 hours a day. \r\n</p>', 'en', NULL, '2015-03-03 06:44:57', '2015-03-03 06:57:26'),
(349, 180, NULL, '<h3>Индивидуальный подход</h3>\r\n<p>\r\n	Каждый проект курирует персональный менеджер отдела поддержки. Клиент вправе выбрать систему расчета. Мы заключаем договор на индивидуальных условиях.\r\n</p>', 'ru', NULL, '2015-03-03 06:46:38', '2015-03-03 06:46:38'),
(350, 180, NULL, '<h3> Individual approach</h3>\r\n<p>\r\n	 Each project is supervised by a personal manager support department. The client has the right to choose the system of calculation. We conclude agreement on individual conditions.\r\n</p>', 'en', NULL, '2015-03-03 06:46:38', '2015-03-03 06:56:34'),
(351, 181, NULL, '<p>\r\n	Сайты тоже нуждаются в постоянных изменениях, развитии и уходе. С нами ваши сайты будут чувствовать себя в полной безопасности.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:07', '2015-03-03 06:47:07'),
(352, 181, NULL, '<p>\r\n	Sites also need to constant change, development and maintenance. With us, your sites will feel completely safe.\r\n</p>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(353, 182, NULL, '<p>\r\n	Рано или поздно любой, даже самый продуманный, сайт необходимо обновлять и развивать. Пока вы наслаждаетесь его безупречным внешним видом, содержание сайта и его техническая платформа устаревают.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(354, 182, NULL, '<p>\r\n	Sooner or later even the most thoughtful, the site must be updated and developed. While you enjoy its perfect appearance, content of the site and its technical platform becomes obsolete.\r\n</p>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(355, 183, NULL, '<p>\r\n	 Поддержка и сопровождение сайта призваны обеспечить его стабильную работу за счет своевременной диагностики и внесения изменений.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(356, 183, NULL, '<p>\r\n	Support and maintenance of the site are designed to provide its stable operation due to timely diagnosis and make changes.\r\n</p>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(357, 184, NULL, '<h2>Поддержка и сопровождение</h2>\r\n<p class="sub-header">\r\n	Существуют различные типы поддержки, которые мы готовы вам предложить.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(358, 184, NULL, '<h2> Support and maintenance \r\n<!-- h2-->\r\n<p class="sub-header">\r\n	 There are different types of support that we are ready to offer you. \r\n	<!-- p-->\r\n</p>\r\n</h2>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(359, 185, NULL, '<h3>Базовая техническая поддержка</h3>\r\n<p>\r\n	Обеспечивает работу и безопасность сайта 24 часа в сутки. Работа включает в себя аренду хостинг-площадки, резервное копирование баз данных и файлов проекта, мониторинг доступности и работоспособности сайта из дата-центров в России, Европе и США в зависимости от выбора аказчика. Мы проследим, чтобы ваш сайт всегда был доступен, а информация — неприкосновенна.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(360, 185, NULL, '<h3> Basic technical support \r\n<!-- h3-->\r\n<p>\r\n	 Provides work and security of the site 24 hours a day. The work includes rent hosting platform, database backup and project files, monitoring the availability and performance of the site data centers in Russia, Europe and the United States, depending on the choice of akazchika. We will make sure that your site has always been available, and information &amp; mdash; inviolable. \r\n	<!-- p-->\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(361, 186, NULL, '<h3>Контентная поддержка</h3>\r\n<p>\r\n	В работе с сайтами нельзя забывать об информационной динамике, которая требует своевременного обновления информации на сайте. Мы отслеживаем тренды и поведение конкурентов и задействуем инструменты по работе с контентом любого формата: тексты, инфографику, изображения и видео.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(362, 186, NULL, '<h3> Content Support \r\n<!-- h3-->\r\n<p>\r\n	 When working with sites should not forget about the dynamics of information, which requires the timely updating of information on this site. We monitor trends and competitor behavior and deploy the tools for working with content in any format: text, infographics, images and video. \r\n	<!-- p-->\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(363, 187, NULL, '<h3>Стратегическое развитие</h3>\r\n<p>\r\n	Комплексное сопровождение, создание стратегии онлайн-присутствия — наша любимая часть работы. Данный тип поддержки предполагает «взгляд со стороны» — оценку контента и анализ реакции пользователей на него, измерение эффективности и меры по оптимизации проектов. Мы работаем с любыми форматами, тематиками и инструментами и предлагаем собственные идеи по улучшению ваших проектов.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(364, 187, NULL, '<h3> Strategic Development \r\n<!-- h3-->\r\n<p>\r\n	 Comprehensive support, creating strategies online presence &amp; mdash; Our favorite part of the job. This type of support is &amp; laquo; view from &amp; raquo; &amp; mdash; evaluation of the content and analysis of user feedback on it, and measuring the effectiveness of measures to optimize projects. We work with any format, topics and tools and offer their own ideas for improving your projects.\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(365, 188, NULL, '<h3>Аналитическая поддержка</h3>\r\n<p>\r\n	Сбор и анализ статистической информации помогает понять, насколько эффективно работает сайт. Игнорировать эти показатели нельзя, как нельзя игнорировать пожелания и реакции своей целевой аудитории. Мы ежемесячно предоставляем вам отчеты о состоянии сайта и рекомендации, которые помогут в дальнейшей работе.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(366, 188, NULL, '<h3> Analytical Support \r\n<!-- h3-->\r\n<p>\r\n	 The collection and analysis of statistical information helps us to understand how effective the site. Ignore these indicators can not, as it is impossible to ignore the wishes and reactions of their target audience. We provide you with monthly reports on the status of the site and recommendations that will help in further work.\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:08', '2015-03-03 06:47:08'),
(367, 189, NULL, '<p>\r\n	Уверенность в собственных силах — это всегда большой плюс, но некоторые вещи лучше доверить специалистам.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(368, 189, NULL, '<p>\r\n	 Self-confidence — it is always a big plus, but some things are best left to professionals. \r\n	<!-- p-->\r\n</p>', 'en', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(369, 190, NULL, '<p>\r\n	Как мы обеспечиваем поддержку и развитие\r\n</p>', 'ru', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(370, 190, NULL, '<p>\r\n	How do we provide support and development\r\n</p>', 'en', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(371, 191, NULL, '<h3>Неутомимость</h3>\r\n<p>\r\n	Мы реагируем на проблему в течение 15 минут и готовы консультировать по работе сайта и решению проблем 24 часа в сутки.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(372, 191, NULL, '<h3> Juggernaut \r\n<!-- h3-->\r\n<p>\r\n	 We will respond to the problem within 15 minutes and are ready to advise on the work site and solving problems 24 hours a day. \r\n	<!-- p-->\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(373, 192, NULL, '<h3>Индивидуальный подход</h3>\r\n<p>\r\n	Каждый проект курирует персональный менеджер отдела поддержки. Клиент вправе выбрать систему расчета. Мы заключаем договор на индивидуальных условиях.\r\n</p>', 'ru', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(374, 192, NULL, '<h3> Individual approach \r\n<!-- h3-->\r\n<p>\r\n	 Each project is supervised by a personal manager support department. The client has the right to choose the system of calculation. We conclude agreement on individual conditions.\r\n</p>\r\n</h3>', 'en', NULL, '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(375, 193, NULL, '<h3>Прозрачность работы</h3>\r\n<p>\r\n	Мы предоставляем доступ в систему управления проектами, где отражены все текущие задачи и сроки их исполнения. Мы не скрываем от вас процесс ценообразования и предоставляем отчет на каждом этапе работы.\r\n</p>', 'ru', NULL, '2015-03-03 06:48:48', '2015-03-03 06:48:48'),
(376, 193, NULL, '<h3> The transparency of the work</h3>\r\n<p>\r\n	 We provide access to the project management system, which reflects all current tasks and the timing of their execution. We do not hide from you the pricing process and provide a report at each stage of the work.\r\n</p>', 'en', NULL, '2015-03-03 06:48:48', '2015-03-03 06:56:54'),
(377, 194, NULL, 'Digital-продакшн агентство, Ростов-на-Дону.<br>\r\n Используя аналитический подход<br>\r\n и нестандартные решения, мы эффективно решаем<br>\r\n задачи наших клиентов.', 'ru', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(378, 194, NULL, 'Digital-production agency, Rostov-on-Don. <br>\r\n Using an analytical approach <br>\r\n and innovative solutions, we effectively solve <br>\r\n problems of our clients.', 'en', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(379, 195, NULL, 'Эффективный рабочий процесс предполагает полное взаимопонимание.                             Мы стремимся собирать вокруг себя людей, которые вдохновляют друг друга каждый день.                             Каждый из нас готов учить других и учиться сам, давать честную оценку своей деятельности                             и брать на себя личную ответственность. Мы убеждены, что такой подход — залог качественной работы.', 'ru', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(380, 195, NULL, '<p>\r\n	 Efficient workflow assumes full understanding.<br>\r\n	 We aim to gather around him people who inspire each other every day.<br>\r\n	 Each of us is willing to teach others and learn myself, to give an honest assessment of their activities<br>\r\n	 and to take personal responsibility. We are convinced that this approach - the key to quality work.\r\n</p>', 'en', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(381, 196, NULL, '<p>\r\n	 Сотрудники нашего агентства стремятся понять желания каждого клиента и воплотить их максимально эффективно. Проблемы клиента мы воспринимаем, как свои собственные, и предлагаем наиболее оптимальное решение. Мы всегда стремимся сделать больше, чем требуется, и открыто говорим о своих сомнениях, чтобы уверенно двигаться вперед.\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(382, 196, NULL, '<p>\r\n	The staff of our agency seeking to understand each client''s desires and translate them effectively. Customer problems we perceive as their own, and offer the best solution. We always strive to do more than is required, and speak openly about their doubts to confidently move forward.\r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(383, 197, NULL, '<p>\r\n	 Как мы обеспечиваем поддержку и развитие\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(384, 197, NULL, '<p>\r\n	How do we provide support and development\r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(385, 198, NULL, '<h3>Веб-сайты и мобильные приложения</h3>\r\n<p>\r\n	Наша цель - внедрение наиболее оптимальных решений для дизайна, интерфейса и юхабилити сайтов, порталов и мобильных приложений.\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(386, 198, NULL, '<h3> Web sites and mobile applications \r\n</h3>\r\n<p>\r\n	 Our goal - the introduction of optimal solutions for design, interface and yuhabiliti sites, portals and mobile applications. \r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(387, 199, NULL, '<h3>Развитие бизнеса в социальных медиа</h3>\r\n<p>\r\n	Работа с социальными медиа – ключевая часть любой рекламной кампании.bМы помогаем повысить лояльность к бренду, эффективно проинформировать ЦА и расширить присутствие бренда в сетию.\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(388, 199, NULL, '<h3> Business Development in Social Media </h3>\r\n<p>\r\n	 Working with social media - a key part of any advertising kampanii.bMy help increase brand loyalty, effectively inform the CA and extend brand presence in setiyu.\r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(389, 200, NULL, '<h3>SEO-оптимизация и Интернет-маркетинг</h3>\r\n<p>\r\n	Решаем комплексные задачи, помогающие продвижению бизнеса в онлайн-среде. Проводим анализ ситуации, разрабатываем стратегию продвижением и обеспечиваем поддержку сайтов.\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(390, 200, NULL, '<h3> SEO-optimization and Internet Marketing</h3>\r\n<p>\r\n	 to solve complex problems, help promote business in the online environment. Analyze the situation, develop a strategy to promote and provide support sites. \r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(391, 201, NULL, 'Наши партнеры', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(392, 201, NULL, 'Our partners', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(393, 202, NULL, '<p>\r\n	Мы гордимся нашими партнерами и проектами, которые удалось реализовать вместе.\r\n</p>\r\n<p>\r\n	Мы всегда открыты к сотрудничеству с другими агентствами и охотно выслушаем все предложения по совместным проектам.\r\n</p>', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(394, 202, NULL, '<p>\r\n	 We are proud of our partners and projects that are able to realize together. \r\n</p>\r\n<p>\r\n	 We are always open to cooperation with other agencies and are willing to listen to all proposals for joint projects. \r\n</p>', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(395, 203, NULL, 'Наши клиенты', 'ru', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(396, 203, NULL, 'Our clients', 'en', NULL, '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(397, 204, NULL, '<p>\r\n	Ваш сайт должен продавать и приносить прибыль.<br>\r\n	Мы знаем, как заставить его делать это.\r\n</p>', 'ru', NULL, '2015-03-03 07:34:43', '2015-03-03 07:34:43'),
(398, 204, NULL, '<p>\r\n	 Your site must sell and make a profit. <br>\r\n	 We know how to get him to do it. \r\n	<!-- p-->\r\n</p>', 'en', NULL, '2015-03-03 07:34:43', '2015-03-03 07:34:43'),
(403, 206, NULL, '<h2>Каких результатов ждать от SEO</h2>\r\n<p class="sub-header">\r\n	Используя комплексный подход и инструменты <nobr>веб-аналитики</nobr>, мы увеличим посещаемость <br>\r\n	сайта и обеспечим рост продаж в вашей компании.\r\n</p>', 'ru', NULL, '2015-03-03 07:37:03', '2015-03-03 07:37:03'),
(404, 206, NULL, '<h2> What kind of results to expect from SEO </h2>\r\n<p class="sub-header">\r\n	 Using an integrated approach and tools <nobr> Web Analytics </nobr>, we will increase the traffic to the site and provide <br>\r\n	 sales growth in your company. \r\n</p>', 'en', NULL, '2015-03-03 07:37:04', '2015-03-03 07:37:56'),
(409, 211, NULL, '<h3>Повышение конверсии</h3>\r\n<p>Увеличиваем рост числа заявок, звонков и обращений при том же рекламном бюджете.</p>', 'ru', NULL, '2015-03-03 07:40:06', '2015-03-03 07:40:06'),
(410, 211, NULL, '<h3> Improving conversion </h3>\r\n<p> Increase the number of applications, phone calls and requests for the same advertising budget. </p>', 'en', NULL, '2015-03-03 07:40:06', '2015-03-03 07:44:22'),
(411, 212, NULL, '<h3>Привлечение посетителей</h3>\r\n<p>Мы можем привлечь на ваш сайт качественную аудиторию по минимальной стоимости за 1 посетителя.</p>', 'ru', NULL, '2015-03-03 07:41:06', '2015-03-03 07:41:06'),
(412, 212, NULL, '<h3> Attracting visitors </h3>\r\n<p> We can attract to your site quality audience at a minimal cost for 1 visitor. </p>', 'en', NULL, '2015-03-03 07:41:06', '2015-03-03 07:44:12'),
(413, 213, NULL, '<h3>Улучшение работы сайта и отдела продаж</h3>\r\n<p>Анализ поможет обнаружить функциональные проблемы вашего сайта, следствием которых является низкая конверсия при высоком количестве посещений.</p>', 'ru', NULL, '2015-03-03 07:41:51', '2015-03-03 07:41:51'),
(414, 213, NULL, '<h3> Improving the operation of the site and Sales </h3>\r\n<p> The analysis helps to detect functional problems of your website, which result in low conversion with a high number of visits. </p>', 'en', NULL, '2015-03-03 07:41:51', '2015-03-03 07:44:01'),
(425, 219, NULL, 'Почему стоит заказывать SEO у нас', 'ru', NULL, '2015-03-03 07:46:04', '2015-03-03 07:46:04'),
(426, 219, NULL, 'Why should we have to order SEO', 'en', NULL, '2015-03-03 07:46:04', '2015-03-03 07:46:04'),
(427, 220, NULL, '<h3>Думаем</h3>\r\n<p>В первую очередь мы проводим анализ состояния сайта и оцениваем влияние на него внутренних и внешних факторов. Нам важно понять, действительно ли сайту требуется данный инструмент. Если мы увидим, что <acronym title="Search engine optimization" lang="en">SEO</acronym> — это не то, что может помочь вашему бизнесу, сразу сообщим вам и порекомендуем другие средства продвижения.</p>', 'ru', NULL, '2015-03-03 07:47:31', '2015-03-03 07:48:57'),
(428, 220, NULL, '<h3> Think </h3>\r\n<p> First of all, we analyze the state of the site and assess the impact on him of internal and external factors. It is important to understand whether the site requires this tool. If we see that the <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> — it is not something that can help your business, immediately notify you and will recommend other means of promotion. </p>', 'en', NULL, '2015-03-03 07:47:31', '2015-03-03 07:51:14'),
(429, 221, NULL, '<h3>Точно знаем, что необходимо</h3>\r\n<p>Мы не отвлекаемся на второстепенные факторы и уверенно движемся к конкретному результату. Конечно, сайт, занимающий первую позицию в топе, выглядит внушительно, но нельзя забывать о главной цели оптимизации — улучшении трафика и увеличении числа заявок.</p>', 'ru', NULL, '2015-03-03 07:48:32', '2015-03-03 07:50:24'),
(430, 221, NULL, '<h3> Just know that it is necessary </h3>\r\n<p> We are not distracted by secondary factors and confidently move to a specific result. Of course, the site, which occupies the first position in the top, it looks impressive, but we must not forget the main goal of optimization &mdash; improve traffic and increase the number of applications. </p>', 'en', NULL, '2015-03-03 07:48:32', '2015-03-03 07:50:24'),
(447, 230, NULL, '<h3>Ценим время</h3>\r\n<p>Реализация стратегии <acronym title="Search engine optimization" lang="en">SEO</acronym> всегда занимает немало времени. Мы тщательно продумываем каждый этап работы,\r\nпотому что знаем, что любые недочеты лучше пресекать в самом начале, нежели корректировать, когда стратегия уже запущена. Так мы экономим и ваше, и наше время.</p>', 'ru', NULL, '2015-03-03 07:54:35', '2015-03-03 07:54:35'),
(448, 230, NULL, '<h3> We appreciate the time </h3>\r\n<p> The implementation of the strategy <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> always takes time. We carefully think through every stage of the work, because we know that any shortcomings better stop right at the beginning, rather than correct, when the strategy is already running. So we save and your and our time. </p>', 'en', NULL, '2015-03-03 07:54:35', '2015-03-03 07:54:35'),
(449, 231, NULL, '<h3>Поддерживаем</h3>\r\n<p>На каждом этапе работы мы предоставляем нашим клиентам отчеты о выполненных задачах, а по завершении работы &mdash; рекомендации по поддержке. Это поможет проследить динамику развития сайта и скорректировать стратегию дальнешей работы. </p>', 'ru', NULL, '2015-03-03 07:55:47', '2015-03-03 07:55:47'),
(450, 231, NULL, '<h3> We support </h3>\r\n<p> At each stage of the work we provide our customers report about the task, and at the conclusion of &mdash; recommendations for support. This will help to trace the dynamics of the site and adjust the strategy dalneshem work. </p>', 'en', NULL, '2015-03-03 07:55:47', '2015-03-03 07:55:47'),
(471, 242, NULL, '<p>Начните продвижение вашего сайта уже сегодня!</p>', 'ru', NULL, '2015-03-03 07:57:11', '2015-03-03 07:57:11'),
(472, 242, NULL, '<p> Start your website promotion today! </p>', 'en', NULL, '2015-03-03 07:57:11', '2015-03-03 08:15:16'),
(495, 254, NULL, '<h2>Сколько стоит поисковая оптимизация</h2>\r\n<p>Цена услуги поисковой оптимизации складывается из оплаты труда специалистов. Кроме того, она варьируется в зависимости от конкурентности продвигаемых товаров и услуг. Поэтому в таких\r\nрегионах, как Москва и <nobr>Санкт-Петербург</nobr> стоимость <acronym title="Search engine optimization" lang="en">SEO</acronym> будет выше, чем в других городах России.</p>', 'ru', NULL, '2015-03-03 07:59:16', '2015-03-03 07:59:16'),
(496, 254, NULL, '<h2> How much is a search engine optimization </h2>\r\n<p> Price search engine optimization services is made up of wage specialists. In addition, it varies depending on the competitiveness of goods and services promoted. Therefore, in such\r\nregions such as Moscow and <nobr> Saint Petersburg </nobr> value <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> will be higher than in other Russian cities. </p>', 'en', NULL, '2015-03-03 07:59:17', '2015-03-03 08:04:35'),
(521, 267, NULL, '<p>Типовой проект по <acronym title="Search engine optimization" lang="en">SEO</acronym> стоит от <strong>10 000</strong> до <strong>70 000</strong> рублей в месяц. Оплата происходит в конце месяца после предоставления отчета о проделанной работе и первых результатах.</p>', 'ru', NULL, '2015-03-03 08:02:46', '2015-03-03 08:02:46'),
(522, 267, NULL, '<p> A typical project for <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> is from <strong> 10,000 </strong> to <strong> 70,000 </strong> rubles a month . Payment is made at the end of the month after submission of the report on the work done and the first results. </p>', 'en', NULL, '2015-03-03 08:02:46', '2015-03-03 08:02:46'),
(549, 281, NULL, '<h2>Мы знаем особенности продвижения<br/> вашей сферы бизнеса</h2>\r\n\r\n<p>У нас есть опыт продвижения сайтов в различных сегментах рынка и маркетинговые аудиты.</p>\r\n\r\n<p>Это значит, что мы уже хорошо знакомы с рыночной ситуацией и знаем ваших\r\n    конкурентов: их стратегии, посещаемость, ключевые запросы, рекламную активность и бюджеты\r\n    в различных сферах. А уже это поможет выстроить нашу собственную стратегию так, чтобы\r\n    учесть все нюансы и расставить акценты правильно.</p>\r\n<ul>\r\n    <li><span>Интернет-магазины</span></li>\r\n    <li><span>Недвижимость</span></li>\r\n    <li><span>Все для ремонта</span></li>\r\n    <li><span>Мебель и предметы интерьера </span></li>\r\n    <li><span>Форекс и валютные операции </span></li>\r\n    <li><span>Химические средства</span></li>\r\n</ul>\r\n<ul>\r\n    <li><span>Строительные компании</span></li>\r\n    <li><span>Рестораны и загородные клубы</span></li>\r\n    <li><span>Одежда и товары для дома </span></li>\r\n    <li><span>Бизнес-центры и ТРК</span></li>\r\n    <li><span>Образовательные порталы</span></li>\r\n    <li><span>Отдых и туризм</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 08:08:32', '2015-03-03 08:08:32'),
(550, 281, NULL, '<h2> We know especially <br/> promote your business scope </h2>\r\n<p> We have experience of promoting websites in various market segments and marketing audits. </p>\r\n<p> This means that we are already familiar with the market situation and know your competition: their strategies, attendance, key questions, advertising activities and budgets in various fields. And already it will help to build our own strategy so that take into account all the nuances and accents correctly. </p>\r\n<ul>\r\n<li><span> Online Stores </span></li>\r\n<li><span> Properties </span></li>\r\n<li><span> All repair </span></li>\r\n<li><span> Furniture and home furnishings </span></li>\r\n<li><span> Forex and currency transactions </span></li>\r\n<li><span> Chemicals </span></li>\r\n</ul>\r\n<ul>\r\n<li><span> Construction Company </span></li>\r\n<li><span> Restaurants and Country Club </span></li>\r\n<li><span> Clothing and household goods </span></li>\r\n<li><span> Business Centers and TRC </span></li>\r\n<li><span> Educational Portals </span></li>\r\n<li><span> Recreation and Tourism </span></li>\r\n</ul>', 'en', NULL, '2015-03-03 08:08:32', '2015-03-03 08:21:45'),
(579, 296, NULL, 'Вы платите не за слова, а за конкретный результат', 'ru', NULL, '2015-03-03 08:24:00', '2015-03-03 08:24:00'),
(580, 296, NULL, 'You do not pay for the words, and for a specific result', 'en', NULL, '2015-03-03 08:24:00', '2015-03-03 08:24:00'),
(611, 312, NULL, 'Гарантия ГРАФЕМА', 'ru', NULL, '2015-03-03 08:24:50', '2015-03-03 08:24:50'),
(612, 312, NULL, 'Warranty grapheme', 'en', NULL, '2015-03-03 08:24:50', '2015-03-03 08:24:50'),
(613, 313, NULL, '<p>\r\n	Ваш сайт должен продавать и приносить прибыль.<br>\r\n	Мы знаем, как заставить его делать это.\r\n</p>', 'ru', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(614, 313, NULL, '<p>\r\n	 Your site must sell and make a profit. <br>\r\n	 We know how to get him to do it. \r\n	<!-- p-->\r\n</p>', 'en', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(615, 314, NULL, '<h2>Каких результатов ждать от SEO</h2>\r\n<p class="sub-header">\r\n	Используя комплексный подход и инструменты <nobr>веб-аналитики</nobr>, мы увеличим посещаемость <br>\r\n	сайта и обеспечим рост продаж в вашей компании.\r\n</p>', 'ru', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(616, 314, NULL, '<h2> What kind of results to expect from SEO </h2>\r\n<p class="sub-header">\r\n	 Using an integrated approach and tools <nobr> Web Analytics </nobr>, we will increase the traffic to the site and provide <br>\r\n	 sales growth in your company. \r\n</p>', 'en', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59');
INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(617, 315, NULL, '<h3>Повышение конверсии</h3>\r\n<p>Увеличиваем рост числа заявок, звонков и обращений при том же рекламном бюджете.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(618, 315, NULL, '<h3> Improving conversion </h3>\r\n<p> Increase the number of applications, phone calls and requests for the same advertising budget. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(619, 316, NULL, '<h3>Привлечение посетителей</h3>\r\n<p>Мы можем привлечь на ваш сайт качественную аудиторию по минимальной стоимости за 1 посетителя.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(620, 316, NULL, '<h3> Attracting visitors </h3>\r\n<p> We can attract to your site quality audience at a minimal cost for 1 visitor. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(621, 317, NULL, '<h3>Улучшение работы сайта и отдела продаж</h3>\r\n<p>Анализ поможет обнаружить функциональные проблемы вашего сайта, следствием которых является низкая конверсия при высоком количестве посещений.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(622, 317, NULL, '<h3> Improving the operation of the site and Sales </h3>\r\n<p> The analysis helps to detect functional problems of your website, which result in low conversion with a high number of visits. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(623, 318, NULL, 'Почему стоит заказывать SEO у нас', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(624, 318, NULL, 'Why should we have to order SEO', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(625, 319, NULL, '<h3>Думаем</h3>\r\n<p>В первую очередь мы проводим анализ состояния сайта и оцениваем влияние на него внутренних и внешних факторов. Нам важно понять, действительно ли сайту требуется данный инструмент. Если мы увидим, что <acronym title="Search engine optimization" lang="en">SEO</acronym> — это не то, что может помочь вашему бизнесу, сразу сообщим вам и порекомендуем другие средства продвижения.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(626, 319, NULL, '<h3> Think </h3>\r\n<p> First of all, we analyze the state of the site and assess the impact on him of internal and external factors. It is important to understand whether the site requires this tool. If we see that the <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> — it is not something that can help your business, immediately notify you and will recommend other means of promotion. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(627, 320, NULL, '<h3>Точно знаем, что необходимо</h3>\r\n<p>Мы не отвлекаемся на второстепенные факторы и уверенно движемся к конкретному результату. Конечно, сайт, занимающий первую позицию в топе, выглядит внушительно, но нельзя забывать о главной цели оптимизации — улучшении трафика и увеличении числа заявок.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(628, 320, NULL, '<h3> Just know that it is necessary </h3>\r\n<p> We are not distracted by secondary factors and confidently move to a specific result. Of course, the site, which occupies the first position in the top, it looks impressive, but we must not forget the main goal of optimization &mdash; improve traffic and increase the number of applications. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(629, 321, NULL, '<h3>Ценим время</h3>\r\n<p>Реализация стратегии <acronym title="Search engine optimization" lang="en">SEO</acronym> всегда занимает немало времени. Мы тщательно продумываем каждый этап работы,\r\nпотому что знаем, что любые недочеты лучше пресекать в самом начале, нежели корректировать, когда стратегия уже запущена. Так мы экономим и ваше, и наше время.</p>', 'ru', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(630, 321, NULL, '<h3> We appreciate the time </h3>\r\n<p> The implementation of the strategy <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> always takes time. We carefully think through every stage of the work, because we know that any shortcomings better stop right at the beginning, rather than correct, when the strategy is already running. So we save and your and our time. </p>', 'en', NULL, '2015-03-03 08:26:00', '2015-03-03 08:26:00'),
(631, 322, NULL, '<h3>Поддерживаем</h3>\r\n<p>На каждом этапе работы мы предоставляем нашим клиентам отчеты о выполненных задачах, а по завершении работы &mdash; рекомендации по поддержке. Это поможет проследить динамику развития сайта и скорректировать стратегию дальнешей работы. </p>', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(632, 322, NULL, '<h3> We support </h3>\r\n<p> At each stage of the work we provide our customers report about the task, and at the conclusion of &mdash; recommendations for support. This will help to trace the dynamics of the site and adjust the strategy dalneshem work. </p>', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(633, 323, NULL, '<p>Начните продвижение вашего сайта уже сегодня!</p>', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(634, 323, NULL, '<p> Start your website promotion today! </p>', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(635, 324, NULL, '<h2>Сколько стоит поисковая оптимизация</h2>\r\n<p>Цена услуги поисковой оптимизации складывается из оплаты труда специалистов. Кроме того, она варьируется в зависимости от конкурентности продвигаемых товаров и услуг. Поэтому в таких\r\nрегионах, как Москва и <nobr>Санкт-Петербург</nobr> стоимость <acronym title="Search engine optimization" lang="en">SEO</acronym> будет выше, чем в других городах России.</p>', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(636, 324, NULL, '<h2> How much is a search engine optimization </h2>\r\n<p> Price search engine optimization services is made up of wage specialists. In addition, it varies depending on the competitiveness of goods and services promoted. Therefore, in such\r\nregions such as Moscow and <nobr> Saint Petersburg </nobr> value <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> will be higher than in other Russian cities. </p>', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(637, 325, NULL, '<p>Типовой проект по <acronym title="Search engine optimization" lang="en">SEO</acronym> стоит от <strong>10 000</strong> до <strong>70 000</strong> рублей в месяц. Оплата происходит в конце месяца после предоставления отчета о проделанной работе и первых результатах.</p>', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(638, 325, NULL, '<p> A typical project for <acronym title = "Search engine optimization" lang = "en"> SEO </acronym> is from <strong> 10,000 </strong> to <strong> 70,000 </strong> rubles a month . Payment is made at the end of the month after submission of the report on the work done and the first results. </p>', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(639, 326, NULL, '<h2>Мы знаем особенности продвижения<br/> вашей сферы бизнеса</h2>\r\n\r\n<p>У нас есть опыт продвижения сайтов в различных сегментах рынка и маркетинговые аудиты.</p>\r\n\r\n<p>Это значит, что мы уже хорошо знакомы с рыночной ситуацией и знаем ваших\r\n    конкурентов: их стратегии, посещаемость, ключевые запросы, рекламную активность и бюджеты\r\n    в различных сферах. А уже это поможет выстроить нашу собственную стратегию так, чтобы\r\n    учесть все нюансы и расставить акценты правильно.</p>\r\n<ul>\r\n    <li><span>Интернет-магазины</span></li>\r\n    <li><span>Недвижимость</span></li>\r\n    <li><span>Все для ремонта</span></li>\r\n    <li><span>Мебель и предметы интерьера </span></li>\r\n    <li><span>Форекс и валютные операции </span></li>\r\n    <li><span>Химические средства</span></li>\r\n</ul>\r\n<ul>\r\n    <li><span>Строительные компании</span></li>\r\n    <li><span>Рестораны и загородные клубы</span></li>\r\n    <li><span>Одежда и товары для дома </span></li>\r\n    <li><span>Бизнес-центры и ТРК</span></li>\r\n    <li><span>Образовательные порталы</span></li>\r\n    <li><span>Отдых и туризм</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(640, 326, NULL, '<h2> We know especially <br/> promote your business scope </h2>\r\n<p> We have experience of promoting websites in various market segments and marketing audits. </p>\r\n<p> This means that we are already familiar with the market situation and know your competition: their strategies, attendance, key questions, advertising activities and budgets in various fields. And already it will help to build our own strategy so that take into account all the nuances and accents correctly. </p>\r\n<ul>\r\n<li><span> Online Stores </span></li>\r\n<li><span> Properties </span></li>\r\n<li><span> All repair </span></li>\r\n<li><span> Furniture and home furnishings </span></li>\r\n<li><span> Forex and currency transactions </span></li>\r\n<li><span> Chemicals </span></li>\r\n</ul>\r\n<ul>\r\n<li><span> Construction Company </span></li>\r\n<li><span> Restaurants and Country Club </span></li>\r\n<li><span> Clothing and household goods </span></li>\r\n<li><span> Business Centers and TRC </span></li>\r\n<li><span> Educational Portals </span></li>\r\n<li><span> Recreation and Tourism </span></li>\r\n</ul>', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(641, 327, NULL, 'Вы платите не за слова, а за конкретный результат', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(642, 327, NULL, 'You do not pay for the words, and for a specific result', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(643, 328, NULL, 'Гарантия ГРАФЕМА', 'ru', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(644, 328, NULL, 'Warranty grapheme', 'en', NULL, '2015-03-03 08:26:01', '2015-03-03 08:26:01'),
(645, 329, NULL, '<p>Мы предоставляем письменные гарантии результатов работы. При невыполнении обязательств, прописанных в договоре, мы возвращаем вам ваши деньги &mdash; потому что значение имеет только результат, а не обещания и заверения.</p>\r\n<p>На каждом этапе работы по <acronym title="Search engine optimization" lang="en">SEO</acronym> вы будете получать отчет, которые позволит проследить динамику работы и зафиксировать текущее состояние продвижения. Мы хотим, чтобы между нами и клиентом не оставалось недосказанностей и на каждый возникающий вопрос вы получали своевременный ответ.</p>', 'ru', NULL, '2015-03-03 08:27:26', '2015-03-03 08:27:26'),
(646, 329, NULL, '<p> We offer a written guarantee results. At default of obligations prescribed in the contract, we will refund you your money &mdash; because the value is only the result but not the promises and assurances. </p>\r\n<p> At each stage of work on the <acronym title = "Search engine optimization" lang = "en"> SEO </acronym>, you will receive a report, which will allow to trace the dynamics of work and fix the current state of progress. We want to make between us and the client had no innuendo and every question that arises you have received a timely response. </p>', 'en', NULL, '2015-03-03 08:27:26', '2015-03-03 08:27:26'),
(647, 330, NULL, '<p>Социальные медиа &mdash; эффективный инструмент <nobr>интернет-маркетинга</nobr>. Мы хорошо знакомы с этой сферой и знаем, как использовать ее по максимуму.</p>', 'ru', NULL, '2015-03-03 08:31:51', '2015-03-03 08:31:51'),
(648, 330, NULL, '<p> Social media &mdash; effective tool <nobr> Internet Marketing </nobr>. We are very familiar with this area and know how to use it to the maximum. </p>', 'en', NULL, '2015-03-03 08:31:51', '2015-03-03 08:31:51'),
(651, 332, NULL, '<p>\r\n	Социальные сети уже давно перестали ассоциироваться только лишь с дружеским общением. Сейчас это полноценная среда для обмена информацией и мнениями, в том числе о брендах и компаниях.\r\n</p>', 'ru', NULL, '2015-03-03 08:46:53', '2015-03-03 08:46:53'),
(652, 332, NULL, '<p>\r\n	Social networks have long ceased to be associated only with the companionship. Now a complete environment for the exchange of information and views, including about brands and companies.\r\n</p>', 'en', NULL, '2015-03-03 08:46:53', '2015-03-03 08:46:53'),
(653, 333, NULL, '<p>\r\n	Одного эффекта присутствия недостаточно. Аудитория хочет не только слушать, но и быть услышанной. Поэтому если вы хотите, чтобы ваша аудитория была лояльна к бренду, нельзя игнорировать работу с социальными медиа.\r\n</p>', 'ru', NULL, '2015-03-03 08:47:49', '2015-03-03 08:47:49'),
(654, 333, NULL, '<p>\r\n	One effect of presence is not enough. The audience wants to not only listen but also to be heard. So if you want your audience has been loyal to the brand, it is impossible to ignore the work with social media.\r\n</p>', 'en', NULL, '2015-03-03 08:47:49', '2015-03-03 08:47:49'),
(661, 337, NULL, 'Какие результаты можно получить с SMM?', 'ru', NULL, '2015-03-03 08:48:45', '2015-03-03 08:48:45'),
(662, 337, NULL, 'What kind of results can be obtained with SMM?', 'en', NULL, '2015-03-03 08:48:45', '2015-03-03 08:48:45'),
(671, 342, NULL, '<ul>\r\n<li><span>Анализ поведения ЦА: модель поведения, изучение ожиданий и степени заинтересованности брендом.</span></li>\r\n<li style="margin-bottom:48px;"><span>Расширение целевой аудитории и более точное<br/>воздействие на нужный сегмент ЦА.</span></li>\r\n<li><span>Поддержка рекламных активностей, увеличение<br/>их охвата и получение вирусного эффекта.</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 08:51:43', '2015-03-03 08:51:43'),
(672, 342, NULL, '<ul>\r\n<li> <span> Analysis of the behavior of CA: a model of behavior, learning expectations and the degree of interest of the brand. </span> </li>\r\n<li style = "margin-bottom: 48px;"> <span> The expansion of the target audience and more accurate <br/> impact on the desired segment of Central Asia. </span> </li>\r\n<li> <span> Support promotional activities, increase their coverage <br/> and getting viral effect. </span> </li></ul>', 'en', NULL, '2015-03-03 08:51:43', '2015-03-03 08:51:43'),
(693, 353, NULL, '<ul>\r\n<li><span>Вовлечение потребителя в жизнь компании и возможность поддерживать обратную связь.</span></li>\r\n<li><span>Привлечение лояльных потребителей, которые формируют сообщества и распространяют информацию о бренде.</span></li>\r\n<li><span>Устранение информации негативного оттенка и своевременная реакция на неблагоприятные мнения.</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 08:56:07', '2015-03-03 08:56:07'),
(694, 353, NULL, '<ul>\r\n<li> <span> The involvement of consumers in the life of the company and the opportunity to provide feedback. </span> </li>\r\n<li> <span> Involvement of loyal customers that form the community and disseminate information about the brand. </span> </li>\r\n<li> <span> Troubleshooting Information negative connotations and timely response to the adverse opinion. </span> </li>\r\n</ul>', 'en', NULL, '2015-03-03 08:56:07', '2015-03-03 08:56:07'),
(707, 360, NULL, '<p><nobr>SMM-стратегия</nobr> отвечает запросам практически любого бизнеса.<br/>Однако и у нее есть свои тонкости и особенности. Чтобы узнать, подойдет ли SMM конкретно вам проконсультируйтесь у нас.</p>', 'ru', NULL, '2015-03-03 08:58:02', '2015-03-03 08:58:02'),
(708, 360, NULL, '<p> <nobr> SMM-strategy </nobr> meets the needs of almost any business. <br/>However, it has its own quirks and peculiarities. To find out whether SMM specifically fit you consult with us. </p>', 'en', NULL, '2015-03-03 08:58:02', '2015-03-03 08:58:02'),
(723, 368, NULL, 'Этапы работы', 'ru', NULL, '2015-03-03 08:58:44', '2015-03-03 08:58:44'),
(724, 368, NULL, 'Stages of work', 'en', NULL, '2015-03-03 08:58:44', '2015-03-03 08:58:44'),
(741, 377, NULL, '<h3>Аналитика</h3>\r\n<p>На данном этапе мы изучаем поведение целевой аудитории, отношение к бренду и формируем начальные рекомендации по конкретным площадкам. В результате создается индивидуальная\r\n<nobr>SMM-стратегия</nobr>, учитывающая все особенности аудитории и преследующая определенный набор целей.</p>', 'ru', NULL, '2015-03-03 09:01:31', '2015-03-03 09:01:31'),
(742, 377, NULL, '<h3> Analytics </h3>\r\n<p> At this point, we study the behavior of the target audience, brand attitude and form of advice on specific sites. The result is an individual\r\n<nobr> SMM-strategy </nobr>, which takes into account all the characteristics of the audience and has a specific set of goals. </p>', 'en', NULL, '2015-03-03 09:01:31', '2015-03-03 09:01:31'),
(743, 378, NULL, '<h3>Планирование</h3>\r\n<p>Разрабатываем креативные концепции и идеи позиционирования, подбор инструментов и наилучшего формата коммуникации.</p>', 'ru', NULL, '2015-03-03 09:02:20', '2015-03-03 09:02:20'),
(744, 378, NULL, '<h3> Planning </h3>\r\n<p> We develop creative concepts and ideas positioning, selection of tools and best communication format. </p>', 'en', NULL, '2015-03-03 09:02:21', '2015-03-03 09:02:21'),
(745, 379, NULL, '<h3>Производство</h3>\r\n<p>Ведем подготовку площадок к внедрению кампании, наполняем контентом и наблюдаем за реакцией аудитории.</p>', 'ru', NULL, '2015-03-03 09:03:31', '2015-03-03 09:03:31'),
(746, 379, NULL, '<h3> production </h3>\r\n<p> We carry a site preparation for the introduction of the campaign, fill content and observe the reaction of the audience. </p>', 'en', NULL, '2015-03-03 09:03:31', '2015-03-03 09:03:31'),
(747, 380, NULL, '<h3>Публикация</h3>\r\n<p>На этом этапе мы подготавливаем площадки к запуску и начинаем работу. Около месяца мы тестируем различные механики и оценивем отклик аудитории. По результатам первого месяца мы корректируем стратегию и определяем оптимальный набор инструментов.</p>', 'ru', NULL, '2015-03-03 09:04:38', '2015-03-03 09:04:38'),
(748, 380, NULL, '<h3> Publish </h3>\r\n<p> At this stage, we prepare for the launch of the site and begin work. About a month we test various mechanics and evaluating the response of the audience. In the first month we adjust strategy and determine the best set of tools. </p>', 'en', NULL, '2015-03-03 09:04:38', '2015-03-03 09:04:38'),
(749, 381, NULL, '<h3>Поддержка бренда в соцсетях</h3>\r\n<p>Ведение рекламной кампании и активное взаимодействие с площадкой. В конце каждого месяца мы предоставляем нашим клиентам промежуточные отчеты о проведенной деятельности.</p>', 'ru', NULL, '2015-03-03 09:05:44', '2015-03-03 09:05:44'),
(750, 381, NULL, '<h3> Support brand in social networks </h3>\r\n<p> Keeping an advertising campaign and active interaction with the site. At the end of each month, we provide our clients with interim reports on activities. </p>', 'en', NULL, '2015-03-03 09:05:44', '2015-03-03 09:05:44'),
(777, 395, NULL, 'Почему стоит доверить SMM нам?', 'ru', NULL, '2015-03-03 09:35:53', '2015-03-03 09:35:53'),
(778, 395, NULL, '<p>\r\n	Why should you trust us SMM?\r\n</p>', 'en', NULL, '2015-03-03 09:35:53', '2015-03-03 09:35:53'),
(807, 410, NULL, '<h3>Стратегия</h3>\r\n<p>Социальные медиа &mdash; восприимчивая среда с тонкой организацией, поэтому для каждого отдельного случая мы используем индивидуальный подход с тщательно продуманным планом и инструментами.</p>', 'ru', NULL, '2015-03-03 09:45:42', '2015-03-03 09:45:42'),
(808, 410, NULL, '<h3> Strategy </h3>\r\n<p> Social media &mdash; susceptibility of the medium with a fine organization, so in each case, we use an individual approach with a carefully thought-out plans and tools. </p>', 'en', NULL, '2015-03-03 09:45:42', '2015-03-03 09:45:42'),
(809, 411, NULL, '<h3>Опыт</h3>\r\n<p>Необходимо помнить, что любой неверный шаг может привести к увеличению числа негативных комментариев о компании. Наш опыт работы с SMM-стратегиями подсказывает нам, как избежать подобных ситуаций.</p>', 'ru', NULL, '2015-03-03 09:46:50', '2015-03-03 09:46:50'),
(810, 411, NULL, '<h3> Experience </h3>\r\n<p> Please be aware that any misstep could lead to an increase in the number of negative comments about the company. Our experience with SMM-strategies tells us how to avoid similar situations. </p>', 'en', NULL, '2015-03-03 09:46:50', '2015-03-03 09:46:50'),
(811, 412, NULL, '<h3>Внимание</h3>\r\n<p>Мы не просто получаем задачу &mdash; мы прислушиваемся к клиенту и пытаемся понять его аудиторию, чтобы наладить между ними продуктивный диалог.</p>', 'ru', NULL, '2015-03-03 09:47:57', '2015-03-03 09:47:57'),
(812, 412, NULL, '<h3> Warning </h3>\r\n<p> We do not just get the problem & mdash; We listen to the customer and try to understand his audience to establish a productive dialogue between them. </p>', 'en', NULL, '2015-03-03 09:47:57', '2015-03-03 09:47:57'),
(847, 430, NULL, '<h2>Сколько стоит работа в соцсетях</h2>\r\n<p>Половину стоимости работы с социальными меди составляет наша работа по ведению группы/страницы/сообщества, а вторая половина бюджета &mdash; затраты на таргетированную рекламу для привлечения внимания к проекту. Окончательная цена зависит от количества площадок, объемов контента и размера рекламного бюджета.</p>', 'ru', NULL, '2015-03-03 09:49:37', '2015-03-03 09:49:37'),
(848, 430, NULL, '<h2> How much is a work in social networks </h2>\r\n<p> Half the cost of working with social copper is our job to conduct group / page / community, and the second half of the budget &mdash; costs of targeted advertising to attract attention to the project. The final price depends on the number of sites, the amount of content and the size of the advertising budget. </p>', 'en', NULL, '2015-03-03 09:49:37', '2015-03-03 09:49:37'),
(885, 449, NULL, '<p>Типичный проект по SMM &mdash; представительство для поддержки существующих клиентов &mdash; стоит примерно 10&ndash;15 тысяч рублей в месяц.</p>', 'ru', NULL, '2015-03-03 09:51:49', '2015-03-03 09:51:49'),
(886, 449, NULL, '<p> A typical project for the SMM &mdash; office to support existing customers &mdash; costs about 10 &ndash; 15 thousand rubles a month. </p>', 'en', NULL, '2015-03-03 09:51:49', '2015-03-03 09:51:49'),
(887, 450, NULL, '<p>Социальные медиа &mdash; эффективный инструмент <nobr>интернет-маркетинга</nobr>. Мы хорошо знакомы с этой сферой и знаем, как использовать ее по максимуму.</p>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(888, 450, NULL, '<p> Social media &mdash; effective tool <nobr> Internet Marketing </nobr>. We are very familiar with this area and know how to use it to the maximum. </p>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(889, 451, NULL, '<p>\r\n	Социальные сети уже давно перестали ассоциироваться только лишь с дружеским общением. Сейчас это полноценная среда для обмена информацией и мнениями, в том числе о брендах и компаниях.\r\n</p>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(890, 451, NULL, '<p>\r\n	Social networks have long ceased to be associated only with the companionship. Now a complete environment for the exchange of information and views, including about brands and companies.\r\n</p>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(891, 452, NULL, '<p>\r\n	Одного эффекта присутствия недостаточно. Аудитория хочет не только слушать, но и быть услышанной. Поэтому если вы хотите, чтобы ваша аудитория была лояльна к бренду, нельзя игнорировать работу с социальными медиа.\r\n</p>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(892, 452, NULL, '<p>\r\n	One effect of presence is not enough. The audience wants to not only listen but also to be heard. So if you want your audience has been loyal to the brand, it is impossible to ignore the work with social media.\r\n</p>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(893, 453, NULL, 'Какие результаты можно получить с SMM?', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(894, 453, NULL, 'What kind of results can be obtained with SMM?', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(895, 454, NULL, '<ul>\r\n<li><span>Анализ поведения ЦА: модель поведения, изучение ожиданий и степени заинтересованности брендом.</span></li>\r\n<li style="margin-bottom:48px;"><span>Расширение целевой аудитории и более точное<br/>воздействие на нужный сегмент ЦА.</span></li>\r\n<li><span>Поддержка рекламных активностей, увеличение<br/>их охвата и получение вирусного эффекта.</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(896, 454, NULL, '<ul>\r\n<li> <span> Analysis of the behavior of CA: a model of behavior, learning expectations and the degree of interest of the brand. </span> </li>\r\n<li style = "margin-bottom: 48px;"> <span> The expansion of the target audience and more accurate <br/> impact on the desired segment of Central Asia. </span> </li>\r\n<li> <span> Support promotional activities, increase their coverage <br/> and getting viral effect. </span> </li></ul>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(897, 455, NULL, '<ul>\r\n<li><span>Вовлечение потребителя в жизнь компании и возможность поддерживать обратную связь.</span></li>\r\n<li><span>Привлечение лояльных потребителей, которые формируют сообщества и распространяют информацию о бренде.</span></li>\r\n<li><span>Устранение информации негативного оттенка и своевременная реакция на неблагоприятные мнения.</span></li>\r\n</ul>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(898, 455, NULL, '<ul>\r\n<li> <span> The involvement of consumers in the life of the company and the opportunity to provide feedback. </span> </li>\r\n<li> <span> Involvement of loyal customers that form the community and disseminate information about the brand. </span> </li>\r\n<li> <span> Troubleshooting Information negative connotations and timely response to the adverse opinion. </span> </li>\r\n</ul>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(899, 456, NULL, '<p><nobr>SMM-стратегия</nobr> отвечает запросам практически любого бизнеса.<br/>Однако и у нее есть свои тонкости и особенности. Чтобы узнать, подойдет ли SMM конкретно вам проконсультируйтесь у нас.</p>', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(900, 456, NULL, '<p> <nobr> SMM-strategy </nobr> meets the needs of almost any business. <br/>However, it has its own quirks and peculiarities. To find out whether SMM specifically fit you consult with us. </p>', 'en', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(901, 457, NULL, 'Этапы работы', 'ru', NULL, '2015-03-03 09:52:35', '2015-03-03 09:52:35'),
(902, 457, NULL, 'Stages of work', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(903, 458, NULL, '<h3>Аналитика</h3>\r\n<p>На данном этапе мы изучаем поведение целевой аудитории, отношение к бренду и формируем начальные рекомендации по конкретным площадкам. В результате создается индивидуальная\r\n<nobr>SMM-стратегия</nobr>, учитывающая все особенности аудитории и преследующая определенный набор целей.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(904, 458, NULL, '<h3> Analytics </h3>\r\n<p> At this point, we study the behavior of the target audience, brand attitude and form of advice on specific sites. The result is an individual\r\n<nobr> SMM-strategy </nobr>, which takes into account all the characteristics of the audience and has a specific set of goals. </p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(905, 459, NULL, '<h3>Планирование</h3>\r\n<p>Разрабатываем креативные концепции и идеи позиционирования, подбор инструментов и наилучшего формата коммуникации.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(906, 459, NULL, '<h3> Planning </h3>\r\n<p> We develop creative concepts and ideas positioning, selection of tools and best communication format. </p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(907, 460, NULL, '<h3>Производство</h3>\r\n<p>Ведем подготовку площадок к внедрению кампании, наполняем контентом и наблюдаем за реакцией аудитории.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(908, 460, NULL, '<h3> production </h3>\r\n<p> We carry a site preparation for the introduction of the campaign, fill content and observe the reaction of the audience. </p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(909, 461, NULL, '<h3>Публикация</h3>\r\n<p>На этом этапе мы подготавливаем площадки к запуску и начинаем работу. Около месяца мы тестируем различные механики и оценивем отклик аудитории. По результатам первого месяца мы корректируем стратегию и определяем оптимальный набор инструментов.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(910, 461, NULL, '<h3> Publish </h3>\r\n<p> At this stage, we prepare for the launch of the site and begin work. About a month we test various mechanics and evaluating the response of the audience. In the first month we adjust strategy and determine the best set of tools. </p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(911, 462, NULL, '<h3>Поддержка бренда в соцсетях</h3>\r\n<p>Ведение рекламной кампании и активное взаимодействие с площадкой. В конце каждого месяца мы предоставляем нашим клиентам промежуточные отчеты о проведенной деятельности.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(912, 462, NULL, '<h3> Support brand in social networks </h3>\r\n<p> Keeping an advertising campaign and active interaction with the site. At the end of each month, we provide our clients with interim reports on activities. </p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(913, 463, NULL, 'Почему стоит доверить SMM нам?', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(914, 463, NULL, '<p>\r\n	Why should you trust us SMM?\r\n</p>', 'en', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(915, 464, NULL, '<h3>Стратегия</h3>\r\n<p>Социальные медиа &mdash; восприимчивая среда с тонкой организацией, поэтому для каждого отдельного случая мы используем индивидуальный подход с тщательно продуманным планом и инструментами.</p>', 'ru', NULL, '2015-03-03 09:52:36', '2015-03-03 09:52:36'),
(916, 464, NULL, '<h3> Strategy </h3>\r\n<p> Social media &mdash; susceptibility of the medium with a fine organization, so in each case, we use an individual approach with a carefully thought-out plans and tools. </p>', 'en', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(917, 465, NULL, '<h3>Опыт</h3>\r\n<p>Необходимо помнить, что любой неверный шаг может привести к увеличению числа негативных комментариев о компании. Наш опыт работы с SMM-стратегиями подсказывает нам, как избежать подобных ситуаций.</p>', 'ru', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(918, 465, NULL, '<h3> Experience </h3>\r\n<p> Please be aware that any misstep could lead to an increase in the number of negative comments about the company. Our experience with SMM-strategies tells us how to avoid similar situations. </p>', 'en', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(919, 466, NULL, '<h3>Внимание</h3>\r\n<p>Мы не просто получаем задачу &mdash; мы прислушиваемся к клиенту и пытаемся понять его аудиторию, чтобы наладить между ними продуктивный диалог.</p>', 'ru', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(920, 466, NULL, '<h3> Warning </h3>\r\n<p> We do not just get the problem & mdash; We listen to the customer and try to understand his audience to establish a productive dialogue between them. </p>', 'en', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(921, 467, NULL, '<h2>Сколько стоит работа в соцсетях</h2>\r\n<p>Половину стоимости работы с социальными меди составляет наша работа по ведению группы/страницы/сообщества, а вторая половина бюджета &mdash; затраты на таргетированную рекламу для привлечения внимания к проекту. Окончательная цена зависит от количества площадок, объемов контента и размера рекламного бюджета.</p>', 'ru', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(922, 467, NULL, '<h2> How much is a work in social networks </h2>\r\n<p> Half the cost of working with social copper is our job to conduct group / page / community, and the second half of the budget &mdash; costs of targeted advertising to attract attention to the project. The final price depends on the number of sites, the amount of content and the size of the advertising budget. </p>', 'en', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(923, 468, NULL, '<p>Типичный проект по SMM &mdash; представительство для поддержки существующих клиентов &mdash; стоит примерно 10&ndash;15 тысяч рублей в месяц.</p>', 'ru', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(924, 468, NULL, '<p> A typical project for the SMM &mdash; office to support existing customers &mdash; costs about 10 &ndash; 15 thousand rubles a month. </p>', 'en', NULL, '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(925, 469, NULL, '<p>Более сложные проекты в соцсетях нельзя оценить заранее, их стоимость полностью зависит от задачи и колеблется от десятков до сотен тысяч рублей в месяц. При разработке стратегии мы можем предложить вам несколько различных по цене схем, чтобы вместе определить оптимальный бюджет и результаты.</p>\r\n<h2>Гарантии и отчетность</h2>\r\n<p>Мы придерживаемся политики максимально прозрачной работы с нашими клиентами. Поэтому на каждом этапе вы получаете подробный отчет о проделанной работе, результатах исследований и пробных запусков стратегий, которые помогут определить результаты работы в социальных медиа.</p>', 'ru', NULL, '2015-03-03 09:54:23', '2015-03-03 09:54:23'),
(926, 469, NULL, '<p> For more complex projects in social networks can not be estimated in advance, their value depends entirely on the problem, ranging from tens to hundreds of thousands of rubles a month. In developing the strategy, we can offer you several different price schemes together to determine the best budget and outcomes. </p>\r\n<h2> Guarantee and reporting </h2>\r\n<p> We maintain a policy as transparent as possible with our customers. Therefore, at each stage you get a detailed report on the work done, the results of research and trial runs strategies that will help determine the outcome of the work in social media. </p>', 'en', NULL, '2015-03-03 09:54:23', '2015-03-03 09:54:23');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=129 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2015-03-02 11:39:38', '2015-03-02 11:52:37'),
(2, 1, 'en', NULL, '2015-03-02 11:39:39', '2015-03-02 11:52:37'),
(17, 9, 'ru', NULL, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(18, 9, 'en', NULL, '2015-03-02 11:52:54', '2015-03-02 11:52:54'),
(19, 10, 'ru', NULL, '2015-03-02 12:21:02', '2015-03-02 12:21:02'),
(20, 10, 'en', NULL, '2015-03-02 12:21:02', '2015-03-02 12:21:02'),
(21, 11, 'ru', NULL, '2015-03-02 12:21:26', '2015-03-02 12:21:26'),
(22, 11, 'en', NULL, '2015-03-02 12:21:26', '2015-03-02 12:21:26'),
(23, 12, 'ru', NULL, '2015-03-02 12:55:58', '2015-03-02 12:55:58'),
(24, 12, 'en', NULL, '2015-03-02 12:55:58', '2015-03-02 12:55:58'),
(43, 22, 'ru', NULL, '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(44, 22, 'en', NULL, '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(71, 36, 'ru', NULL, '2015-03-03 06:47:07', '2015-03-03 06:47:07'),
(72, 36, 'en', NULL, '2015-03-03 06:47:07', '2015-03-03 06:47:07'),
(73, 37, 'ru', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(74, 37, 'en', NULL, '2015-03-03 06:53:05', '2015-03-03 06:53:05'),
(75, 38, 'ru', NULL, '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(76, 38, 'en', NULL, '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(99, 50, 'ru', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(100, 50, 'en', NULL, '2015-03-03 08:25:59', '2015-03-03 08:25:59'),
(101, 51, 'ru', NULL, '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(102, 51, 'en', NULL, '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(127, 64, 'ru', NULL, '2015-03-03 09:52:34', '2015-03-03 09:52:34'),
(128, 64, 'en', NULL, '2015-03-03 09:52:34', '2015-03-03 09:52:34');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '999',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=57 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `order`, `created_at`, `updated_at`) VALUES
(1, '1425390485_1445.jpg', '0', 999, '2015-03-03 10:48:05', '2015-03-03 10:48:05'),
(2, '1425390511_1504.jpg', '0', 999, '2015-03-03 10:48:31', '2015-03-03 10:48:31'),
(3, '1425390547_1043.jpg', '0', 999, '2015-03-03 10:49:07', '2015-03-03 10:49:07'),
(4, '1425390588_1637.jpg', '0', 999, '2015-03-03 10:49:48', '2015-03-03 10:49:48'),
(5, '1425390652_1130.jpg', '0', 999, '2015-03-03 10:50:53', '2015-03-03 10:50:53'),
(6, '1425390710_1729.jpg', '0', 999, '2015-03-03 10:51:50', '2015-03-03 10:51:50'),
(7, '1425390735_1183.jpg', '0', 999, '2015-03-03 10:52:15', '2015-03-03 10:52:15'),
(8, '1425390761_1286.jpg', '0', 999, '2015-03-03 10:52:41', '2015-03-03 10:52:41'),
(9, '1425390780_1494.jpg', '0', 999, '2015-03-03 10:53:00', '2015-03-03 10:53:00'),
(10, '1425391594_1885.jpg', '0', 999, '2015-03-03 11:06:34', '2015-03-03 11:06:34'),
(11, '1425391597_1139.jpg', '0', 999, '2015-03-03 11:06:37', '2015-03-03 11:06:37'),
(12, '1425391652_1237.jpg', '0', 999, '2015-03-03 11:07:32', '2015-03-03 11:07:32'),
(13, '1425391655_1561.jpg', '0', 999, '2015-03-03 11:07:36', '2015-03-03 11:07:36'),
(14, '1425391696_1247.jpg', '0', 999, '2015-03-03 11:08:16', '2015-03-03 11:08:16'),
(15, '1425391700_1205.jpg', '0', 999, '2015-03-03 11:08:20', '2015-03-03 11:08:20'),
(16, '1425391736_1836.jpg', '0', 999, '2015-03-03 11:08:56', '2015-03-03 11:08:56'),
(17, '1425391738_1694.jpg', '0', 999, '2015-03-03 11:08:59', '2015-03-03 11:08:59'),
(18, '1425394138_1864.png', '0', 999, '2015-03-03 11:48:58', '2015-03-03 11:48:58'),
(19, '1425394163_1714.png', '0', 999, '2015-03-03 11:49:23', '2015-03-03 11:49:23'),
(20, '1425394222_1758.png', '0', 999, '2015-03-03 11:50:22', '2015-03-03 11:50:22'),
(21, '1425394225_1697.png', '0', 999, '2015-03-03 11:50:25', '2015-03-03 11:50:25'),
(22, '1425394277_1672.png', '0', 999, '2015-03-03 11:51:18', '2015-03-03 11:51:18'),
(23, '1425394280_1531.png', '0', 999, '2015-03-03 11:51:20', '2015-03-03 11:51:20'),
(24, '1425394324_1312.png', '0', 999, '2015-03-03 11:52:04', '2015-03-03 11:52:04'),
(25, '1425394327_1750.png', '0', 999, '2015-03-03 11:52:07', '2015-03-03 11:52:07'),
(26, '1425394377_1081.png', '0', 999, '2015-03-03 11:52:57', '2015-03-03 11:52:57'),
(27, '1425394380_1932.png', '0', 999, '2015-03-03 11:53:00', '2015-03-03 11:53:00'),
(28, '1425394434_1569.png', '0', 999, '2015-03-03 11:53:54', '2015-03-03 11:53:54'),
(29, '1425394437_1455.png', '0', 999, '2015-03-03 11:53:57', '2015-03-03 11:53:57'),
(30, '1425394479_1307.png', '0', 999, '2015-03-03 11:54:39', '2015-03-03 11:54:39'),
(31, '1425394496_1765.png', '0', 999, '2015-03-03 11:54:56', '2015-03-03 11:54:56'),
(32, '1425394532_1073.png', '0', 999, '2015-03-03 11:55:32', '2015-03-03 11:55:32'),
(33, '1425394535_1461.png', '0', 999, '2015-03-03 11:55:35', '2015-03-03 11:55:35'),
(34, '1425394581_1597.png', '0', 999, '2015-03-03 11:56:21', '2015-03-03 11:56:21'),
(35, '1425394584_1247.png', '0', 999, '2015-03-03 11:56:24', '2015-03-03 11:56:24'),
(36, '1425395144_1680.png', '0', 999, '2015-03-03 12:05:45', '2015-03-03 12:05:45'),
(37, '1425395164_1568.png', '0', 999, '2015-03-03 12:06:04', '2015-03-03 12:06:04'),
(38, '1425395764_1148.png', '0', 999, '2015-03-03 12:16:04', '2015-03-03 12:16:04'),
(39, '1425395770_1237.png', '0', 999, '2015-03-03 12:16:10', '2015-03-03 12:16:10'),
(40, '1425395813_1207.png', '0', 999, '2015-03-03 12:16:53', '2015-03-03 12:16:53'),
(41, '1425395815_1072.png', '0', 999, '2015-03-03 12:16:56', '2015-03-03 12:16:56'),
(42, '1425395857_1207.png', '0', 999, '2015-03-03 12:17:37', '2015-03-03 12:17:37'),
(43, '1425395860_1596.png', '0', 999, '2015-03-03 12:17:40', '2015-03-03 12:17:40'),
(44, '1425395912_1448.png', '0', 999, '2015-03-03 12:18:32', '2015-03-03 12:18:32'),
(45, '1425395914_1384.png', '0', 999, '2015-03-03 12:18:34', '2015-03-03 12:18:34'),
(46, '1425395959_1742.png', '0', 999, '2015-03-03 12:19:19', '2015-03-03 12:19:19'),
(47, '1425395962_1311.png', '0', 999, '2015-03-03 12:19:22', '2015-03-03 12:19:22'),
(48, '1425395996_1463.png', '0', 999, '2015-03-03 12:19:56', '2015-03-03 12:19:56'),
(49, '1425395998_1636.png', '0', 999, '2015-03-03 12:19:58', '2015-03-03 12:19:58'),
(50, '1425396325_1158.png', '0', 999, '2015-03-03 12:25:25', '2015-03-03 12:25:25'),
(51, '1425396327_1500.png', '0', 999, '2015-03-03 12:25:27', '2015-03-03 12:25:27'),
(52, '1425396363_1023.png', '0', 999, '2015-03-03 12:26:03', '2015-03-03 12:26:03'),
(53, '1425396365_1049.png', '0', 999, '2015-03-03 12:26:05', '2015-03-03 12:26:05'),
(54, '1425396393_1160.png', '0', 999, '2015-03-03 12:26:33', '2015-03-03 12:26:33'),
(55, '1425396398_1055.png', '0', 999, '2015-03-03 12:26:38', '2015-03-03 12:26:38'),
(56, '1425396572_1658.png', '0', 999, '2015-03-03 12:29:32', '2015-03-03 12:29:32');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=129 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'Page', 1, 'ru', 'Графема', '', '', NULL, '', '2015-03-02 11:39:39', '2015-03-02 11:39:39'),
(2, 'Page', 1, 'en', 'Grapheme', '', '', NULL, '', '2015-03-02 11:39:39', '2015-03-02 11:39:39'),
(17, 'Page', 9, 'ru', 'Графема', '', '', NULL, '', '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(18, 'Page', 9, 'en', 'Grapheme', '', '', NULL, '', '2015-03-02 11:52:55', '2015-03-02 11:52:55'),
(19, 'Page', 10, 'ru', 'Портфолио', '', '', NULL, '', '2015-03-02 12:21:02', '2015-03-02 12:21:02'),
(20, 'Page', 10, 'en', 'Portfolio', '', '', NULL, '', '2015-03-02 12:21:02', '2015-03-02 12:21:02'),
(21, 'Page', 11, 'ru', 'Портфолио', '', '', NULL, '', '2015-03-02 12:21:26', '2015-03-02 12:21:26'),
(22, 'Page', 11, 'en', 'Portfolio', '', '', NULL, '', '2015-03-02 12:21:26', '2015-03-02 12:21:26'),
(23, 'Page', 12, 'ru', 'Агенство', '', '', NULL, '', '2015-03-02 12:55:58', '2015-03-02 12:55:58'),
(24, 'Page', 12, 'en', '', '', '', NULL, '', '2015-03-02 12:55:58', '2015-03-02 12:55:58'),
(43, 'Page', 22, 'ru', 'Поддежка', '', '', NULL, '', '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(44, 'Page', 22, 'en', '', '', '', NULL, '', '2015-03-03 06:14:03', '2015-03-03 06:14:03'),
(71, 'Page', 36, 'ru', 'Поддежка', '', '', NULL, '', '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(72, 'Page', 36, 'en', '', '', '', NULL, '', '2015-03-03 06:47:09', '2015-03-03 06:47:09'),
(73, 'Page', 37, 'ru', 'Агенство', '', '', NULL, '', '2015-03-03 06:53:06', '2015-03-03 06:53:06'),
(74, 'Page', 37, 'en', '', '', '', NULL, '', '2015-03-03 06:53:07', '2015-03-03 06:53:07'),
(75, 'Page', 38, 'ru', 'SEO', '', '', NULL, '', '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(76, 'Page', 38, 'en', '', '', '', NULL, '', '2015-03-03 07:33:35', '2015-03-03 07:33:35'),
(99, 'Page', 50, 'ru', 'SEO', '', '', NULL, '', '2015-03-03 08:26:02', '2015-03-03 08:26:02'),
(100, 'Page', 50, 'en', '', '', '', NULL, '', '2015-03-03 08:26:02', '2015-03-03 08:26:02'),
(101, 'Page', 51, 'ru', 'SMM', '', '', NULL, '', '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(102, 'Page', 51, 'en', '', '', '', NULL, '', '2015-03-03 08:29:23', '2015-03-03 08:29:23'),
(127, 'Page', 64, 'ru', 'SMM', '', '', NULL, '', '2015-03-03 09:52:37', '2015-03-03 09:52:37'),
(128, 'Page', 64, 'en', '', '', '', NULL, '', '2015-03-03 09:52:37', '2015-03-03 09:52:37');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('e0986e54127ef3f976192bea2e75e15b82c29436', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOTFFQ2V4NmtSZGhtUjcxaUhQSGxqeWd6cmNibnAzUnFqMGR3akhteSI7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6MjI6IlBIUERFQlVHQkFSX1NUQUNLX0RBVEEiO2E6MDp7fXM6NToiZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjUzOTY3MjU7czoxOiJjIjtpOjE0MjUzNzI1MTM7czoxOiJsIjtzOjE6IjAiO319', 1425396725);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'language', 'ru', '2015-03-02 10:21:48', '2015-03-02 10:21:48');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `storages`
--

INSERT INTO `storages` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'menu', 'main_menu', '{"title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u043e\\u0435 \\u043c\\u0435\\u043d\\u044e","nesting_level":"1","container":"<ul>%elements%<\\/ul>","element_container":"<li%attr%>%element%%children%<\\/li>","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","items":{"1":{"text":"{{ trans(\\"interface.menu.about\\") }}","title":"","type":"page","page_id":"12","id":"1","active_regexp":""},"2":{"text":"{{ trans(\\"interface.menu.portfolio\\") }}","title":"","type":"page","page_id":"10","id":"2","active_regexp":""},"3":{"text":"{{ trans(\\"interface.menu.support\\") }}","title":"","type":"page","page_id":"22","id":"3","active_regexp":""},"4":{"text":"{{ trans(\\"interface.menu.seo\\") }}","title":"","type":"page","page_id":"38","id":"4","active_regexp":""},"5":{"text":"{{ trans(\\"interface.menu.smm\\") }}","title":"","type":"page","page_id":"51","id":"5","active_regexp":""},"6":{"url":"#show-contacts","text":"{{ trans(\\"interface.menu.contacts\\") }}","title":"","type":"link","id":"6","active_regexp":""}},"order":"[{\\"id\\":1},{\\"id\\":2},{\\"id\\":3},{\\"id\\":4},{\\"id\\":5},{\\"id\\":6}]"}', '2015-03-03 09:59:14', '2015-03-03 11:01:58'),
(2, 'menu_placement', 'menu_placement', '{"main_menu":"main_menu"}', '2015-03-03 09:59:14', '2015-03-03 09:59:14');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
`id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Разработчик', '', 'developer@test.ru', 1, '$2y$10$LRRj9vISWH2i3ELvXMb7nONdczIEUV1aNgWy0/Y3u0YHDXgg2wZtG', '', '', '', 0, 'luyPh5eaeu4BYyAqsPhoULHRk3p0ajtDnNhH2Mi8RG5ulL7WlPcoj5vwNKPA', '2015-03-02 10:21:48', '2015-03-02 11:00:26'),
(2, 2, 'Администратор', '', 'admin@test.ru', 1, '$2y$10$qqrQCU8h9q6TMuWYsoYLpOTxLMhILB4AO5VIAtTl3L1dD.7Hbkzi6', '', '', '', 0, 'udqlwRtknxtVM8yAMDuJk5m9iZkXI5k7v308gDrOw78LxcPThkyq0ngOBIAP', '2015-03-02 10:21:48', '2015-03-02 11:00:52'),
(3, 3, 'Модератор', '', 'moder@test.ru', 1, '$2y$10$hIbrhZhFP8DooR8grPrNBuptpb2/8vfpxERB6CSBGjYE9Ds9k9HRS', '', '', '', 0, NULL, '2015-03-02 10:21:48', '2015-03-02 10:21:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
 ADD PRIMARY KEY (`id`), ADD KEY `actions_group_id_index` (`group_id`), ADD KEY `actions_module_index` (`module`), ADD KEY `actions_action_index` (`action`), ADD KEY `actions_status_index` (`status`);

--
-- Indexes for table `catalog_attributes`
--
ALTER TABLE `catalog_attributes`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `catalog_attributes_slug_unique` (`slug`), ADD KEY `catalog_attributes_active_index` (`active`), ADD KEY `catalog_attributes_attributes_group_id_index` (`attributes_group_id`), ADD KEY `catalog_attributes_type_index` (`type`), ADD KEY `catalog_attributes_lft_index` (`lft`), ADD KEY `catalog_attributes_rgt_index` (`rgt`);

--
-- Indexes for table `catalog_attributes_groups`
--
ALTER TABLE `catalog_attributes_groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `catalog_attributes_groups_slug_unique` (`slug`), ADD KEY `catalog_attributes_groups_category_id_index` (`category_id`), ADD KEY `catalog_attributes_groups_active_index` (`active`), ADD KEY `catalog_attributes_groups_lft_index` (`lft`), ADD KEY `catalog_attributes_groups_rgt_index` (`rgt`);

--
-- Indexes for table `catalog_attributes_groups_meta`
--
ALTER TABLE `catalog_attributes_groups_meta`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `attributes_group_id_language` (`attributes_group_id`,`language`), ADD KEY `catalog_attributes_groups_meta_attributes_group_id_index` (`attributes_group_id`), ADD KEY `catalog_attributes_groups_meta_language_index` (`language`), ADD KEY `catalog_attributes_groups_meta_active_index` (`active`), ADD KEY `catalog_attributes_groups_meta_name_index` (`name`);

--
-- Indexes for table `catalog_attributes_meta`
--
ALTER TABLE `catalog_attributes_meta`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `attribute_id_language` (`attribute_id`,`language`), ADD KEY `catalog_attributes_meta_attribute_id_index` (`attribute_id`), ADD KEY `catalog_attributes_meta_language_index` (`language`), ADD KEY `catalog_attributes_meta_active_index` (`active`), ADD KEY `catalog_attributes_meta_name_index` (`name`);

--
-- Indexes for table `catalog_attributes_values`
--
ALTER TABLE `catalog_attributes_values`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `attribute_product_language` (`attribute_id`,`product_id`,`language`), ADD KEY `catalog_attributes_values_product_id_index` (`product_id`), ADD KEY `catalog_attributes_values_attribute_id_index` (`attribute_id`), ADD KEY `catalog_attributes_values_language_index` (`language`), ADD KEY `catalog_attributes_values_lft_index` (`lft`), ADD KEY `catalog_attributes_values_rgt_index` (`rgt`);

--
-- Indexes for table `catalog_categories`
--
ALTER TABLE `catalog_categories`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `catalog_categories_slug_unique` (`slug`), ADD KEY `catalog_categories_active_index` (`active`), ADD KEY `catalog_categories_lft_index` (`lft`), ADD KEY `catalog_categories_rgt_index` (`rgt`);

--
-- Indexes for table `catalog_categories_meta`
--
ALTER TABLE `catalog_categories_meta`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `category_language` (`category_id`,`language`), ADD KEY `catalog_categories_meta_category_id_index` (`category_id`), ADD KEY `catalog_categories_meta_language_index` (`language`), ADD KEY `catalog_categories_meta_active_index` (`active`);

--
-- Indexes for table `catalog_orders`
--
ALTER TABLE `catalog_orders`
 ADD PRIMARY KEY (`id`), ADD KEY `catalog_orders_status_id_index` (`status_id`), ADD KEY `catalog_orders_total_sum_index` (`total_sum`), ADD KEY `catalog_orders_client_id_index` (`client_id`);

--
-- Indexes for table `catalog_orders_products`
--
ALTER TABLE `catalog_orders_products`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `order_product` (`order_id`,`product_id`), ADD KEY `catalog_orders_products_order_id_index` (`order_id`), ADD KEY `catalog_orders_products_product_id_index` (`product_id`), ADD KEY `catalog_orders_products_price_index` (`price`);

--
-- Indexes for table `catalog_orders_products_attributes`
--
ALTER TABLE `catalog_orders_products_attributes`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `order_product_attribute` (`order_id`,`product_id`,`attribute_id`), ADD KEY `catalog_orders_products_attributes_order_id_index` (`order_id`), ADD KEY `catalog_orders_products_attributes_product_id_index` (`product_id`), ADD KEY `catalog_orders_products_attributes_attribute_id_index` (`attribute_id`), ADD KEY `catalog_orders_products_attributes_value_index` (`value`);

--
-- Indexes for table `catalog_orders_statuses`
--
ALTER TABLE `catalog_orders_statuses`
 ADD PRIMARY KEY (`id`), ADD KEY `catalog_orders_statuses_sort_order_index` (`sort_order`);

--
-- Indexes for table `catalog_orders_statuses_history`
--
ALTER TABLE `catalog_orders_statuses_history`
 ADD PRIMARY KEY (`id`), ADD KEY `catalog_orders_statuses_history_order_id_index` (`order_id`), ADD KEY `catalog_orders_statuses_history_status_id_index` (`status_id`), ADD KEY `catalog_orders_statuses_history_changer_id_index` (`changer_id`), ADD KEY `catalog_orders_statuses_history_changer_name_index` (`changer_name`);

--
-- Indexes for table `catalog_orders_statuses_meta`
--
ALTER TABLE `catalog_orders_statuses_meta`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `status_id_language` (`status_id`,`language`), ADD KEY `catalog_orders_statuses_meta_status_id_index` (`status_id`), ADD KEY `catalog_orders_statuses_meta_language_index` (`language`);

--
-- Indexes for table `catalog_products`
--
ALTER TABLE `catalog_products`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `catalog_products_article_unique` (`article`), ADD UNIQUE KEY `catalog_products_slug_unique` (`slug`), ADD KEY `catalog_products_active_index` (`active`), ADD KEY `catalog_products_category_id_index` (`category_id`), ADD KEY `catalog_products_amount_index` (`amount`), ADD KEY `catalog_products_lft_index` (`lft`), ADD KEY `catalog_products_rgt_index` (`rgt`);

--
-- Indexes for table `catalog_products_meta`
--
ALTER TABLE `catalog_products_meta`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `product_id_language` (`product_id`,`language`), ADD KEY `catalog_products_meta_product_id_index` (`product_id`), ADD KEY `catalog_products_meta_language_index` (`language`), ADD KEY `catalog_products_meta_active_index` (`active`), ADD KEY `catalog_products_meta_name_index` (`name`), ADD KEY `catalog_products_meta_price_index` (`price`);

--
-- Indexes for table `catalog_related_products`
--
ALTER TABLE `catalog_related_products`
 ADD UNIQUE KEY `related_products_pair` (`product_id`,`related_product_id`), ADD KEY `catalog_related_products_product_id_index` (`product_id`), ADD KEY `catalog_related_products_related_product_id_index` (`related_product_id`);

--
-- Indexes for table `dictionary`
--
ALTER TABLE `dictionary`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `dictionary_slug_unique` (`slug`), ADD KEY `dictionary_name_index` (`name`), ADD KEY `dictionary_entity_index` (`entity`), ADD KEY `dictionary_view_access_index` (`view_access`), ADD KEY `dictionary_order_index` (`order`);

--
-- Indexes for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_fields_values_language_index` (`language`), ADD KEY `dictionary_fields_values_key_index` (`key`), ADD KEY `dictionary_fields_values_value_index` (`value`);

--
-- Indexes for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_textfields_values_language_index` (`language`), ADD KEY `dictionary_textfields_values_key_index` (`key`);

--
-- Indexes for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_version_of_index` (`version_of`), ADD KEY `dictionary_values_dic_id_index` (`dic_id`), ADD KEY `dictionary_values_slug_index` (`slug`), ADD KEY `dictionary_values_order_index` (`order`), ADD KEY `dictionary_values_lft_index` (`lft`), ADD KEY `dictionary_values_rgt_index` (`rgt`);

--
-- Indexes for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_values_meta_language_index` (`language`);

--
-- Indexes for table `dictionary_values_rel`
--
ALTER TABLE `dictionary_values_rel`
 ADD PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`), ADD KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_dic_id_index` (`dicval_parent_dic_id`), ADD KEY `dictionary_values_rel_dicval_child_dic_id_index` (`dicval_child_dic_id`), ADD KEY `dictionary_values_rel_dicval_parent_field_index` (`dicval_parent_field`(255));

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_version_of_index` (`version_of`), ADD KEY `pages_slug_index` (`slug`), ADD KEY `pages_type_id_index` (`type_id`), ADD KEY `pages_publication_index` (`publication`), ADD KEY `pages_start_page_index` (`start_page`), ADD KEY `pages_in_menu_index` (`in_menu`), ADD KEY `pages_order_index` (`order`);

--
-- Indexes for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_page_id_index` (`page_id`), ADD KEY `pages_blocks_slug_index` (`slug`), ADD KEY `pages_blocks_order_index` (`order`);

--
-- Indexes for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_meta_block_id_index` (`block_id`), ADD KEY `pages_blocks_meta_language_index` (`language`);

--
-- Indexes for table `pages_meta`
--
ALTER TABLE `pages_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_meta_page_id_index` (`page_id`), ADD KEY `pages_meta_language_index` (`language`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
 ADD PRIMARY KEY (`id`), ADD KEY `photos_gallery_id_index` (`gallery_id`), ADD KEY `photos_order_index` (`order`);

--
-- Indexes for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
 ADD PRIMARY KEY (`id`), ADD KEY `rel_mod_gallery_module_index` (`module`), ADD KEY `unit_id` (`module`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
 ADD PRIMARY KEY (`id`), ADD KEY `unit_id` (`module`), ADD KEY `seo_module_index` (`module`), ADD KEY `seo_unit_id_index` (`unit_id`), ADD KEY `seo_language_index` (`language`), ADD KEY `seo_url_index` (`url`(255));

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `settings_module_index` (`module`), ADD KEY `settings_name_index` (`name`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `storages_module_index` (`module`), ADD KEY `storages_name_index` (`name`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
 ADD PRIMARY KEY (`id`), ADD KEY `uploads_mime1_index` (`mime1`), ADD KEY `uploads_mime2_index` (`mime2`), ADD KEY `uploads_module_index` (`module`), ADD KEY `uploads_unit_id_index` (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `catalog_attributes`
--
ALTER TABLE `catalog_attributes`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_attributes_groups`
--
ALTER TABLE `catalog_attributes_groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_attributes_groups_meta`
--
ALTER TABLE `catalog_attributes_groups_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_attributes_meta`
--
ALTER TABLE `catalog_attributes_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_attributes_values`
--
ALTER TABLE `catalog_attributes_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_categories`
--
ALTER TABLE `catalog_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_categories_meta`
--
ALTER TABLE `catalog_categories_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders`
--
ALTER TABLE `catalog_orders`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders_products`
--
ALTER TABLE `catalog_orders_products`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders_products_attributes`
--
ALTER TABLE `catalog_orders_products_attributes`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders_statuses`
--
ALTER TABLE `catalog_orders_statuses`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders_statuses_history`
--
ALTER TABLE `catalog_orders_statuses_history`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_orders_statuses_meta`
--
ALTER TABLE `catalog_orders_statuses_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_products`
--
ALTER TABLE `catalog_products`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `catalog_products_meta`
--
ALTER TABLE `catalog_products_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary`
--
ALTER TABLE `dictionary`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=131;
--
-- AUTO_INCREMENT for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=470;
--
-- AUTO_INCREMENT for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=927;
--
-- AUTO_INCREMENT for table `pages_meta`
--
ALTER TABLE `pages_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=129;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=129;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
